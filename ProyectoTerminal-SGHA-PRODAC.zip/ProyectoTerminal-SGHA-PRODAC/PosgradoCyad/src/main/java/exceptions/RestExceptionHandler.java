package exceptions;

import javax.persistence.EntityNotFoundException;

import org.apache.log4j.Logger;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
/**
 * clase controladora de errores, sobreescibe el handle nativo de las excepciones
 * 
 * @author Enrique Ramírez Martínez
 *
 */
@ControllerAdvice
public class RestExceptionHandler {

	
	private static final Logger log = Logger.getLogger(RestExceptionHandler.class);

	@ExceptionHandler(org.springframework.web.bind.MethodArgumentNotValidException.class)
    public ResponseEntity<Object> handleArgumentNotValid(org.springframework.web.bind.MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        ErrrorModel error = new ErrrorModel(HttpStatus.BAD_REQUEST, "Validation Error", ex.getBindingResult().toString());
        log.warn(error.toString());
        return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
    }
    
    @ExceptionHandler(EntityNotFoundException.class)
    private ResponseEntity<ErrrorModel> handleEntityNotFound(EntityNotFoundException ex){
        ErrrorModel error = new ErrrorModel(HttpStatus.NOT_FOUND, "Entity not found", ex.getMessage());
        log.warn(error.toString());
        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }
    @ExceptionHandler(Exception.class)
    private ResponseEntity<Object> handleExcepctionGeneral(Exception ex)
    {
    	ErrrorModel error = new ErrrorModel(HttpStatus.BAD_REQUEST, "General error in server in: ", ex.getMessage());
    	log.error(error.toString());
		return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
    	
    }
}