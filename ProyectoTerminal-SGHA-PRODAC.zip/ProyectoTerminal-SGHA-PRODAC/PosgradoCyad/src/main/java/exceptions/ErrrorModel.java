package exceptions;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
/**
 * clase entidad representa la entidad ErrorModel,encargada de ser un template para el manejo de errores
 * 
 * @author Enrique Ramírez Martínez
 *
 */
public class ErrrorModel {
	
	private HttpStatus httpStatus;

    private LocalDateTime timestamp;

    private String message;

    private String details;

    
    public ErrrorModel(HttpStatus httpStatus, String message, String details) {
        this.httpStatus = httpStatus;
        this.timestamp = LocalDateTime.now();
        this.message = message;
        this.details = details;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public String getMessage() {
        return message;
    }

    public String getDetails() {
        return details;
    }
    
    @Override
    public String toString()
    {
		return httpStatus + "  " + timestamp + "  " + message + "  " + details;
    	
    }
}
