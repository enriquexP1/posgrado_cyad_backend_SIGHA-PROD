package responses;
/**
 * clase entidad representa la entidad ApiResult
 * Encargada de ser un template para el manejo de respuestas de los servicios para ligar
 * producciones académicas con autores/editores 
 * 
 * @author Enrique Ramírez Martínez
 *
 */
public class ApiResult {
	String message;
	Boolean response;
	public ApiResult()
	{
		
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Boolean getResponse() {
		return response;
	}
	public void setResponse(Boolean response) {
		this.response = response;
	}
	
}
