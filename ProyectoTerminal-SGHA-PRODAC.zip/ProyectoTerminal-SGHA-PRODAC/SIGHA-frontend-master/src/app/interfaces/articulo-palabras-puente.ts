import { Articulo } from "./articulo";
import { PalabrasClave } from "./palabras-clave";
export interface ArticuloPalabrasPuente {
    id: number;
    articulo : Articulo;
    palabraArticulo : PalabrasClave;
}
