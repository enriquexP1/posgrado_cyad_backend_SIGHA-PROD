import { RolParticipacion } from "./rol-participacion";
import { TipoDesarrollo } from "./tipo-desarrollo";
import { DocumentoRespaldo } from "./documento-respaldo";
export interface Desarrollo {
    id?: number;
    nombre : string;
    objetivos : string;
    resumen : string;
    fecha_de_entrega: Date;
    rolParticipacion : RolParticipacion;
    tipoDesarrollo : TipoDesarrollo;
    documentoRespaldo : DocumentoRespaldo;
    
    
}
