import { DocumentoReseña } from "./documento-reseña";
import { PalabrasClave } from "./palabras-clave";
export interface DocumentoReseñaPalabasPuente {
    id : number;
    documentoReseña : DocumentoReseña;
    palabraDocumentoReseña : PalabrasClave;
}
