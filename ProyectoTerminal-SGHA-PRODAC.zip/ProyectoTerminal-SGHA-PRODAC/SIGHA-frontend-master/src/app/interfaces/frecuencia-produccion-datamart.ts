export interface FrecuenciaProduccionDatamart {
    id: number;
    fecha: Date;
    cuenta: number;
}
