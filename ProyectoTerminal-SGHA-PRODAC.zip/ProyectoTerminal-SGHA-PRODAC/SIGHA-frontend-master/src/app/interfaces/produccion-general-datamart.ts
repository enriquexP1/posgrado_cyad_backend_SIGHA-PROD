import { AutorEditorDatamartProduccion } from "./autor-editor-datamart-produccion";
import { ProduccionAcademicaDatamart } from "./produccion-academica-datamart";

export interface ProduccionGeneralDatamart {
    id: number;
    autorEditorDatamrt : AutorEditorDatamartProduccion;
    produccionAcademicaDatamart: ProduccionAcademicaDatamart;
    produccionAcademica: number;
    fechaProduccion: Date;
    orden: number;

}
