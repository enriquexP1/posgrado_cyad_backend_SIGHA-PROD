import { Libro } from "./libro";
import { PalabrasClave } from "./palabras-clave";
export interface LibroPalabrasPuente {
    id : number;
    libro : Libro;
    palabraLibro : PalabrasClave;
}
