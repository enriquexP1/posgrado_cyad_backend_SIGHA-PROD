export interface ApiResult {
    message?: string;
    response?: boolean;
}
