export interface Editor {
    id: number;
    nombre: string;
    primerApellido : string;
    segundoApellido :string;
    editorial :string;
    profesor_alumno: boolean;
}
