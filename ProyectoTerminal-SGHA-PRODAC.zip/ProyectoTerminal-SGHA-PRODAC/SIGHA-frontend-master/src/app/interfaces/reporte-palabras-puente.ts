import { Reporte } from "./reporte";
import { PalabrasClave } from "./palabras-clave";
export interface ReportePalabrasPuente {
    id : number;
    reporte : Reporte;
    palabraReporte : PalabrasClave
}
