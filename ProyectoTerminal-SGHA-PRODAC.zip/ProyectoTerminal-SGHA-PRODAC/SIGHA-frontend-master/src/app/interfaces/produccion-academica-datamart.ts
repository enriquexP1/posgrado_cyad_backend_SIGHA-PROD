export interface ProduccionAcademicaDatamart {
    id: number;
    tipoProduccion: string;
}
