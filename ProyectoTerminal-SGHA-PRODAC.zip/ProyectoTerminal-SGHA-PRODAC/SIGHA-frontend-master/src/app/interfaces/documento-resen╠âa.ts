export interface DocumentoReseña {
    id?: number;
    documento_reseña : boolean;
    titulo : string;
    fecha_de_entrega: Date;
    nombre: string;
    primer_apellido :string;
    segundo_apellido:string;
    pagina_inicio : number;
    pagina_fin : number;
}
