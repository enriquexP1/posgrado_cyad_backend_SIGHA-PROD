export interface PlanEstudios{
    id: number;
    clave: number;
    creditos: number;
    duracion: number;
    division: string;
    activo: boolean;
}