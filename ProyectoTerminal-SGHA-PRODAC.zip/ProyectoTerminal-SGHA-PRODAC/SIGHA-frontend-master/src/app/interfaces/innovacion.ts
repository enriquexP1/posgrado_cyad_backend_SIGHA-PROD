export interface Innovacion {
    id ?: number;
    nombre: string;
    fecha_fin: Date;
    descripcion :string;
}
