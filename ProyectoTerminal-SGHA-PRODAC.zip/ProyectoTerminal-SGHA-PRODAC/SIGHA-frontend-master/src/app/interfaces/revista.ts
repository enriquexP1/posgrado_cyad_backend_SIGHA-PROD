
export interface Revista {
   id?: number;
   nombre?: string;
   numero ?: number;
   issn? : string;
}
