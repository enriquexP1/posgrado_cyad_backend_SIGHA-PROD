export interface CuentaProduccionDatamart {
    id: number;
    tipoProduccion: string;
    cuenta: number;
}
