export interface AreaInvestigacion {
    id: number;
    area_investigacion: string;
    activo: boolean;
}