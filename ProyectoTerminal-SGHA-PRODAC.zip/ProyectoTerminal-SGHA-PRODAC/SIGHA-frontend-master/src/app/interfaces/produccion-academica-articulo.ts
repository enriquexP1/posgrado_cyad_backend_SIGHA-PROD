import { Articulo } from "./articulo";
import { Autor } from "./autor";
import { AutorEditor } from "./autor-editor";
import { Orden } from "./orden";
export interface ProduccionAcademicaArticulo {
    id: number;
    articulo : Articulo;
    autor :AutorEditor;
    orden : Orden;
}
