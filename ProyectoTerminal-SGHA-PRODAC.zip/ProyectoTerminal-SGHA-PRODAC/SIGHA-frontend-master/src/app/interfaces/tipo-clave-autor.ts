export interface TipoClaveAutor{
    id: number;
    tipo: string;
    activo: boolean;
}