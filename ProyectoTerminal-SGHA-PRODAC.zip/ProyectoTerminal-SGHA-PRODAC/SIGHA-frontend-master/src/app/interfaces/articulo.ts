import { Revista } from "./revista";
export interface Articulo {

    id? : number;
    doi: string;
    titulo : string;
    fecha_publicacion: Date;
    fecha_aceptacion: Date;
    pagina_inicio: number;
    pagina_fin : number;
    revista: Revista; 
    pais : string;
    idioma : string;
}
