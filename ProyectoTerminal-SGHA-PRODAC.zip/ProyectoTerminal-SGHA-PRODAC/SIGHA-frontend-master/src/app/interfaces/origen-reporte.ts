export interface OrigenReporte {
    id?: number;
    origen? :string;
}
