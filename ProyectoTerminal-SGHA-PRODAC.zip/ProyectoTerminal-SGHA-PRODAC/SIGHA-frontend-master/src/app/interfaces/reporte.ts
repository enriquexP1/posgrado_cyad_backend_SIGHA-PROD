import { InstitucionProduccionAcademica } from "./institucion-produccion-academica";
import { OrigenReporte } from "./origen-reporte";
export interface Reporte {
    id?: number;
    titulo : string;
    fecha_entrega:Date;
    fecha_publicacion :Date;
    numero_paginas: number;
    descripcion : string;
    objetivos: string;
    institucion : InstitucionProduccionAcademica;
    origenReporte : OrigenReporte;
}
