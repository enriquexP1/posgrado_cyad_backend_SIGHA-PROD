export interface ProfesorAlumnoPrincipalDatamart {
    id: number;
    profesorAlumno: boolean;
    cuenta: number;
}
