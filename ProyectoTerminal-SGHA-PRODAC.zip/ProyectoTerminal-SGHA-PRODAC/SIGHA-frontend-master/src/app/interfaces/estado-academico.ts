export interface EstadoAcademico{
    id: number;
    estado: string;
    activo: boolean;
}