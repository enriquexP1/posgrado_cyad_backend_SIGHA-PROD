export interface TipoProyecto{
    id:number;
    tipo?: string;
    activo: boolean;
}