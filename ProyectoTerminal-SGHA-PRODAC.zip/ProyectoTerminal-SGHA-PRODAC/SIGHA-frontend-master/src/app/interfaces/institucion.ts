export interface Institucion{
    id?: number;
    institucion: string;
    activo: boolean;
}