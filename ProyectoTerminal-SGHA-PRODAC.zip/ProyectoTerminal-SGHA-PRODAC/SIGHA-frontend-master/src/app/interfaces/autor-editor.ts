export interface AutorEditor {
    id?: number;
    nombre : string;
    primerApellido: string;
    segundoApellido: string;
    profesor_alumno: boolean;
    autorEditor: boolean;
    editorial: string;
}
