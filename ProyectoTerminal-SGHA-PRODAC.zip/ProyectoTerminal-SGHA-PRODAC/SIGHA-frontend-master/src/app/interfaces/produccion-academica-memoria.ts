import { Autor } from "./autor";
import { Editor } from "./editor";
import { Memoria } from "./memoria";
import { Orden } from "./orden";
export interface ProduccionAcademicaMemoria {
    id : number;
    memoria: Memoria;
    autor : Autor;
    editor : Editor;
    orden : Orden;
}
