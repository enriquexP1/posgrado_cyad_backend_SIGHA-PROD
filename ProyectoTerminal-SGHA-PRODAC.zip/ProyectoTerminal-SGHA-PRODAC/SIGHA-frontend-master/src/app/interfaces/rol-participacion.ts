export interface RolParticipacion {
    id? : number;
    rol : string;
    rolParticipacion?: string; 
}
