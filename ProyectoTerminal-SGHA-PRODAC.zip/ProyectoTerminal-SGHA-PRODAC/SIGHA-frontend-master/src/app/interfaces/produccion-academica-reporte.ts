import { Reporte } from "./reporte";
import { Editor } from "./editor";
import { Orden } from "./orden";
export interface ProduccionAcademicaReporte {
    id: number;
    reporte : Reporte;
    editor : Editor;
    orden: Orden;
}
