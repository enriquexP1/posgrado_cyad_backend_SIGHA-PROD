export interface AutorEditorCuentaProduccionDatamart {
    id: number;
    profesorAlumno: boolean;
    autorEditor: boolean;
    nombre : string;
    apellidoPaterno: string;
    apellidoMaterno: string;
    articulo: number;
    libro: number;
    innovacion: number;
    conferencia: number;
    presentacion: number;
    desarrollo: number;
    memoria: number;
    reporte: number;
    documento: number;
    resena: number;

}
