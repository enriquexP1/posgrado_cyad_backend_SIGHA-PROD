import { Autor } from "./autor";
import { ConferenciaPresentacion } from "./conferencia-presentacion";
export interface ProduccionAcademicaConferenciaPresetacion {
    id:number;
    conferenciaPresentacion : ConferenciaPresentacion;
}
