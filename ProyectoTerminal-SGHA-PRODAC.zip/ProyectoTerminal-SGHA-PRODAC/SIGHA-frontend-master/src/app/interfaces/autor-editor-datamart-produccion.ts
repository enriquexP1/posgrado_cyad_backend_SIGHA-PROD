export interface AutorEditorDatamartProduccion {
    id: number;
    profesorAlumno: boolean;
    autorEditor: boolean;
    nombre : string;
    apellidoPaterno: string;
    apellidoMaterno: string;
    editorial: string;
}
