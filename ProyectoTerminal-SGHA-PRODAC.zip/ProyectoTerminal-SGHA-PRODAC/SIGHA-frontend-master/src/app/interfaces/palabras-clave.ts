export interface PalabrasClave {
    id : number;
    palabra : string;
}
