import { Desarrollo } from "./desarrollo";
import { Autor } from "./autor";
import { Orden } from "./orden";
import { AutorEditor } from "./autor-editor";
export interface ProduccionAcademicaDesarrollo {
    id: number;
    desarrollo : Desarrollo;
    autor :AutorEditor;
    orden : Orden;
}
