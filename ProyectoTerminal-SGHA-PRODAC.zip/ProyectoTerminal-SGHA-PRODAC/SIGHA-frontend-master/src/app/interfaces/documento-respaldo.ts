export interface DocumentoRespaldo {
    id?: number;
    documento: string;
    documentoRespaldo?: string;
}
