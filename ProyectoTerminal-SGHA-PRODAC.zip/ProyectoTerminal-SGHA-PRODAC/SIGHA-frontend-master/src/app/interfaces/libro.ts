export interface Libro {
    id?:number;
    isbn :string;
    titulo: string;
    pais :string;
    idioma:string;
    fecha_publicacion:Date;
    volumen : number;
    tomo : number;
    doi : string;
    numero_paginas: number;
    editorial :string;
    numero_edicion : number;
    año_edicion : number;
    titulo_traducido: string;
    idioma_traducido: string;
}
