import { Libro } from "./libro";
import { Autor } from "./autor";
import { Orden } from "./orden";
import { AutorEditor } from "./autor-editor";
export interface ProduccionAcademicaLibro {
    id?:number;
    libro: Libro;
    autor : AutorEditor;
    orden : Orden;

}
