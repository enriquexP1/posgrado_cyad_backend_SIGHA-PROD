import { DocumentoReseña } from "./documento-reseña";
import { Editor } from "./editor";
import { Orden } from "./orden";
export interface ProduccionAcademicaDocumentosReseñas {
    id : number;
    documento_reseña: DocumentoReseña;
    editor : Editor;
    orden : Orden;
}
