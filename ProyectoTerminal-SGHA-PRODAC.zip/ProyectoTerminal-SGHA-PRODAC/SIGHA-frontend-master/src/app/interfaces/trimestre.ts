export interface Trimestre{
    id : number;
    fecha_inicio : Date;
    fecha_fin : Date;
    trimestre : string;
}