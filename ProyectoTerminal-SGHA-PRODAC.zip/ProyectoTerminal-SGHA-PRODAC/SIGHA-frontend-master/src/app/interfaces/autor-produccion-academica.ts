export interface AutorProduccionAcademica {
    id: number;
    nombre: string;
    primerApellido : string;
    segundoApellido :string;
    profesor_alumno: boolean;
}
