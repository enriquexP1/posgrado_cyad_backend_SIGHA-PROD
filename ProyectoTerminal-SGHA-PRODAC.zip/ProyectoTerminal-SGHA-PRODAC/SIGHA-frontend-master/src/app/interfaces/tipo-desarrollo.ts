export interface TipoDesarrollo {
    id? : number;
    tipo : string;
    tipoDesarrollo?: string;
}
