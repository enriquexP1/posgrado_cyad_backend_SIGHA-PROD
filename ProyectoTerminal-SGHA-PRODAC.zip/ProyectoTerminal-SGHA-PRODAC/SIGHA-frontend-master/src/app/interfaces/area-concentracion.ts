export interface AreaConcentracion {
    id: number;
    area: string;
}
