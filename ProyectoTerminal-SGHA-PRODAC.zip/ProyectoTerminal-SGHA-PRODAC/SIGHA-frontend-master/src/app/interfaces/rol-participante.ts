export interface RolParticipante{
    id : number;
    rol : string;
    activo : boolean;
}