export interface Orden {
    id: number;
    orden : number;
}
