import { Innovacion } from "./innovacion";
import { Autor } from "./autor";
import { Orden } from "./orden";
import { AutorEditor } from "./autor-editor";
export interface ProduccionAcademicaInnovacion {
    id : number;
    innovacion : Innovacion;
    autor : AutorEditor;
    orden : Orden;
}
