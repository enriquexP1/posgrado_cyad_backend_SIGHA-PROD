export interface Requisito{
    id: number;
    documento: string;
    tipo: string;
    activo: boolean;
}