export interface GrupoProtocolo{
    id : number;
    clave : string;
    activo : boolean;
}