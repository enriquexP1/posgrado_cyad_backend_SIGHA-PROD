export interface TipoProduccion {
    id: number;
    tipo?: String;
}