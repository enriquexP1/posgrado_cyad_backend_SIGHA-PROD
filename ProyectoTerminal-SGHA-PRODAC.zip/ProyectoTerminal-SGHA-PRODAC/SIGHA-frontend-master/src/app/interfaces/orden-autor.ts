export interface OrdenAutor{
    id: number;
    orden: string;
    activo: boolean;
}