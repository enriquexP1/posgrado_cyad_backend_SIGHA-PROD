export interface InstitucionProduccionAcademica {
    id?: number;
    nombre?: string;
    publica_privada ?: boolean;
    tipo_institucion ?: string;
}
