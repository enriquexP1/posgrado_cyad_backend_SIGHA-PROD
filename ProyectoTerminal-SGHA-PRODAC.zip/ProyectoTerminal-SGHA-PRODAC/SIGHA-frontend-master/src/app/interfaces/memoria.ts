export interface Memoria {
    id?: number;
    titulo: string ;
    nombre : string;
    primer_apellido: string;
    segundo_apellido:string;
    titulo_publicacion: string;
    pagina_inicio: number;
    pagina_fin : number;
    fecha_publicacion: Date;
    pais :string;
}
