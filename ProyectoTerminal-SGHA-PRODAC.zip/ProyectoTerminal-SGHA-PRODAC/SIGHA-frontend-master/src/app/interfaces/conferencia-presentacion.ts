export interface ConferenciaPresentacion {
    id ?: number;
    conferencia_presentacion :  boolean;
    titulo : string;
    evento : string;
    fecha_presentacion : Date;
    ciudad : string;
    pais : string;
}
