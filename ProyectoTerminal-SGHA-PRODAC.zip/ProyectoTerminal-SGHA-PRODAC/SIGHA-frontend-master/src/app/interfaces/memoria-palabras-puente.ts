import { Memoria } from "./memoria";
import { PalabrasClave } from "./palabras-clave";
export interface MemoriaPalabrasPuente {
    id: number;
    memoria : Memoria;
    palabraMemoria: PalabrasClave;
}
