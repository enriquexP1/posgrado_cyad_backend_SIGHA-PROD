export interface Correo {
    correo: string;
    tipo: string;
    activo: boolean;
}