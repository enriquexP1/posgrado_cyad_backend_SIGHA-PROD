import { HttpClient, HttpRequest } from '@angular/common/http';
import { EventEmitter, Injectable, Output } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Alumno } from '../interfaces/alumno';
import { AreaConcentracion } from '../interfaces/area-concentracion';
import { AreaInvestigacion } from '../interfaces/areaInvestiongacion';
import { Articulo } from '../interfaces/articulo';
import { Aspirante } from '../interfaces/aspirante';
import { Autor } from '../interfaces/autor';
import { AutorEditor } from '../interfaces/autor-editor';
import { AutorEditorCuentaProduccionDatamart } from '../interfaces/autor-editor-cuenta-produccion-datamart';
import { AutorEditorDatamartProduccion } from '../interfaces/autor-editor-datamart-produccion';
import { AutorProduccionAcademica } from '../interfaces/autor-produccion-academica';
import { ConferenciaPresentacion } from '../interfaces/conferencia-presentacion';
import { Correo } from '../interfaces/correo';
import { CuentaProduccionDatamart } from '../interfaces/cuenta-produccion-datamart';
import { DatosAcademicos } from '../interfaces/datos-academicos';
import { DatosIngreso } from '../interfaces/datos-ingreso';
import { Departamento } from '../interfaces/departamento';
import { Desarrollo } from '../interfaces/desarrollo';
import { Direccion } from '../interfaces/direccion';
import { Division } from '../interfaces/division';
import { DocumentoReseña } from '../interfaces/documento-reseña';
import { DocumentoRespaldo } from '../interfaces/documento-respaldo';
import { Editor } from '../interfaces/editor';
import { EstadoAcademico } from '../interfaces/estado-academico';
import { EstadoAspirante } from '../interfaces/estado-aspirante';
import { FrecuenciaProduccionDatamart } from '../interfaces/frecuencia-produccion-datamart';
import { GrupoAutores } from '../interfaces/grupo-autores';
import { GrupoProtocolo } from '../interfaces/grupo-protocolo';
import { Innovacion } from '../interfaces/innovacion';
import { Institucion } from '../interfaces/institucion';
import { InstitucionProduccionAcademica } from '../interfaces/institucion-produccion-academica';
import { Libro } from '../interfaces/libro';
import { Memoria } from '../interfaces/memoria';
import { Nivel } from '../interfaces/nivel';
import { Orden } from '../interfaces/orden';
import { OrdenAutor } from '../interfaces/orden-autor';
import { OrigenReporte } from '../interfaces/origen-reporte';
import { PalabrasClave } from '../interfaces/palabras-clave';
import { Participante } from '../interfaces/participante';
import { PlanEstudios } from '../interfaces/plan-estudios';
import { Produccion } from '../interfaces/produccion';
import { ProduccionAcademicaArticulo } from '../interfaces/produccion-academica-articulo';
import { ProduccionAcademicaConferenciaPresetacion } from '../interfaces/produccion-academica-conferencia-presetacion';
import { ProduccionAcademicaDatamart } from '../interfaces/produccion-academica-datamart';
import { ProduccionAcademicaDesarrollo } from '../interfaces/produccion-academica-desarrollo';
import { ProduccionAcademicaDocumentosReseñas } from '../interfaces/produccion-academica-documentos-reseñas';
import { ProduccionAcademicaInnovacion } from '../interfaces/produccion-academica-innovacion';
import { ProduccionAcademicaLibro } from '../interfaces/produccion-academica-libro';
import { ProduccionAcademicaMemoria } from '../interfaces/produccion-academica-memoria';
import { ProduccionAcademicaReporte } from '../interfaces/produccion-academica-reporte';
import { ProduccionGeneralDatamart } from '../interfaces/produccion-general-datamart';
import { Profesor } from '../interfaces/profesor';
import { ProfesorAlumnoPrincipalDatamart } from '../interfaces/profesor-alumno-principal-datamart';
import { Proyecto } from '../interfaces/proyecto';
import { Reporte } from '../interfaces/reporte';
import { Revista } from '../interfaces/revista';
import { RolParticipacion } from '../interfaces/rol-participacion';
import { TipoClaveAutor } from '../interfaces/tipo-clave-autor';
import { TipoDesarrollo } from '../interfaces/tipo-desarrollo';
import { TipoProduccion } from '../interfaces/tipo-produccion';
import { TipoProyecto } from '../interfaces/tipo-proyecto';
import { Trimestre } from '../interfaces/trimestre';
import { ApiResult } from '../interfaces/api-result';

@Injectable({
  providedIn: 'root'
})
export class CyadService {

  private baseUrl = environment.baseUrl;

  @Output() disparadorData:EventEmitter<any> = new EventEmitter();
  
  constructor(private http : HttpClient) { }

  //REST Alumnos
  public getAlumnos(): Observable<any>{
    return this.http.get(this.baseUrl+'/alumnos');
  }

  public getAlumnoDetail(index: number){
    return this.http.get<Alumno>(this.baseUrl+`/alumno/${index}`);
  }

  public postAlumno(alumn: any){
    return this.http.post<number>(this.baseUrl+'/alumno',alumn);
  }

  public putAlumno(alumn: Alumno){
    return this.http.put<Alumno>(this.baseUrl+`/alumnoUpdate`,alumn);
  }

  public deleteAlumno(id: number){
    return this.http.delete<Alumno>(this.baseUrl+`/alumno/?id=${id}`);
  }

  //REST Datos academicos
  public getAllDatosAcademicos():Observable<any>{
    return this.http.get( this.baseUrl + '/datos');
  }

  public getDatosAcademicos(index : number){
    return this.http.get<any>( this.baseUrl + `/datos/${index}`);
  }

  public postDatosAcademicos(datos: any){
    return this.http.post<DatosAcademicos>(this.baseUrl+'/dato',datos);
  }

  public putDatosAcademicos(datos: any){
    return this.http.put<DatosAcademicos>(this.baseUrl+`/datoUpdate`,datos);
  }

  public deleteDatosAcademicos(id: number){
    return this.http.delete<DatosAcademicos>(this.baseUrl+`/dato/?id=${id}`);
  }

  //REST Datos de ingreso
  public getAllDatosIngreso():Observable<any>{
    return this.http.get( this.baseUrl + '/datosIngresos');
  }

  public getDatosIngreso(index : number){
    return this.http.get<any>( this.baseUrl + `/datosIngreso/${index}`);
  }

  public postDatosIngreso(datos: any){
    return this.http.post<DatosIngreso>(this.baseUrl+'/datosIngreso',datos);
  }

  public putDatosIngreso(datos: any){
    return this.http.put<DatosIngreso>(this.baseUrl+`/datosIngresoUpdate`,datos);
  }

  public deleteDatosIngreso(id: number){
    return this.http.delete<DatosIngreso>(this.baseUrl+`/datosIngreso/?id=${id}`);
  }

  //REST Correos
  public getAllCorreos():Observable<any>{
    return this.http.get( this.baseUrl + '/correos');
  }

  public getCorreosAlumno(index : number){
    return this.http.get<any>( this.baseUrl + `/correos-alumno/${index}`);
  }

  public postCorreo(correo: any){
    return this.http.post<Correo>(this.baseUrl+'/correo',correo);
  }

  public putCorreo(correo: any){
    return this.http.put<Correo>(this.baseUrl+`/correoUpdate`,correo);
  }

  public deleteCorreo(id: number){
    return this.http.delete<Correo>(this.baseUrl+`/correo/?id=${id}`);
  }

  public deleteCorreoCoincidir( correo : string, tipo : string, id : number){
    console.log('data ',correo, tipo)
    return this.http.delete<Correo>(this.baseUrl+`/correo-coincidir?correo=${correo}&tipo=${tipo}&id=${id}`);
  }
  
  //REST Profesor
  public getProfesores():Observable<any>{
    return this.http.get( this.baseUrl + '/profesores');
  }

  public getProfesorDetails(index : number){
    return this.http.get<any>( this.baseUrl + `/profesor/${index}`);
  }

  public postProfesor(profe: any){
    return this.http.post<Profesor>(this.baseUrl+'/profesor',profe);
  }

  public putProfesor(profe: any){
    return this.http.put<Profesor>(this.baseUrl+`/profesorUpdate`,profe);
  }

  public deleteProfesor(id: number){
    return this.http.delete<Profesor>(this.baseUrl+`/profesor/?id=${id}`);
  }

  //REST producciones
  public getProducciones():Observable<any>{
    return this.http.get( this.baseUrl + '/producciones'  )
  }

  public getProduccionDetail(index: number){
    return this.http.get<Produccion>( this.baseUrl + `/produccion/${index}`);
  }

  public postProduccion(prod: any){
    return this.http.post<Produccion>(this.baseUrl+'/produccion',prod);
  }

  public putProduccion(prod: any){
    return this.http.put<Produccion>(this.baseUrl+`/produccionUpdate`,prod);
  }

  public deleteProduccion(id: number){
    return this.http.delete<Produccion>(this.baseUrl+`/produccion/?id=${id}`);
  }

  public upload(produccion : any, file : File, grupo_autores : any[]) {
    //auxiliar
    let product : Produccion;
    //registrando datos de la produccion
    this.http.post<Produccion>(this.baseUrl+'/produccion',produccion).subscribe({
      next:(res)=>{
        product = res;

        // creando formdata
        const formData = new FormData();
        //almacena el archivo como "file"
        formData.append("file", file);
        // haciendo la petición para cargararchivo en bd
        this.http.post<number>(`${this.baseUrl}/produccion-upload?id=${product.id}`,formData).subscribe({
          next:(res)=>{
            //actualizando el id
            for (let i = 0; i < grupo_autores.length; i++) {
              grupo_autores[i].produccion.id = res;
              this.postGruposAutores(grupo_autores[i]).subscribe({
                next:(res)=>{
                  console.log('agregando al grupo de autores',res);
                }
              });//post grupo de autores
            }
          }
        });//post archivo
      }
    });//post produccion
  }

  //REST proyectos
  public getProyectos():Observable<any>{
    return this.http.get( this.baseUrl + '/proyectos'  )
  }

  public getProyectoDetail(index: number){
    return this.http.get<Proyecto>( this.baseUrl + `/proyecto/${index}`);
  }

  public postProyecto(proyect: any){
    return this.http.post<Proyecto>(this.baseUrl+'/proyecto',proyect);
  }

  public putProyecto(proyect: any){
    return this.http.put<Proyecto>(this.baseUrl+`/proyectoUpdate`,proyect);
  }

  public deleteProyecto(id: number){
    return this.http.delete<Proyecto>(this.baseUrl+`/proyecto/?id=${id}`);
  }

  //REST tipos de proyectos
  public getTiposProyectos():Observable<any>{
    return this.http.get( this.baseUrl + '/tiposProyectos'  )
  }

  public getTipoProyectoDetail(index: number){
    return this.http.get<TipoProyecto>( this.baseUrl + `/tipoProyecto/${index}`);
  }

  public postTipoProyecto(tipo: TipoProyecto){
    return this.http.post<TipoProyecto>(this.baseUrl+'/tipoProyecto',tipo);
  }

  public putTipoProyecto(tipo: TipoProyecto){
    return this.http.put<TipoProyecto>(this.baseUrl+`/tipoProyectoUpdate`,tipo);
  }

  public deleteTipoProyecto(id: number){
    return this.http.delete<TipoProyecto>(this.baseUrl+`/tipoProyecto/?id=${id}`);
  }

  //REST grupo protocolo
  public getGruposProtocolos():Observable<any>{
    return this.http.get( this.baseUrl + '/gruposProtocolo'  )
  }

  public getGrupoProtocolo(index: number){
    return this.http.get<GrupoProtocolo>( this.baseUrl + `/grupoProtocolo/${index}`);
  }

  public postGrupoProtocoloClave(){
    return this.http.post<GrupoProtocolo>(this.baseUrl+'/newgrupoProtocolo',null);
  }

  public postGrupoProtocolo(grupo: any){
    return this.http.post<GrupoProtocolo>(this.baseUrl+'/grupoProtocolo',grupo);
  }

  public putGrupoProtocolo(grupo: any){
    return this.http.put<GrupoProtocolo>(this.baseUrl+`/grupoProtocoloUpdate`,grupo);
  }

  public deleteGrupoProtocolo(id: number){
    return this.http.delete<GrupoProtocolo>(this.baseUrl+`/grupoProtocolo/?id=${id}`);
  }

  //REST Participantes del grupo de protocolo
  public getParticipantes():Observable<any>{
    return this.http.get( this.baseUrl + '/participantes'  )
  }

  public getParticipante(index: number){
    return this.http.get<Participante>( this.baseUrl + `/participante/${index}`);
  }

  public postParticipante(participante: any){
    return this.http.post<Participante>(this.baseUrl+'/participante',participante);
  }

  public putParticipante(participante: any){
    return this.http.put<Participante>(this.baseUrl+`/participanteUpdate`,participante);
  }

  public deleteParticipante(id: number){
    return this.http.delete<Participante>(this.baseUrl+`/participante/?id=${id}`);
  }

  //REST areas de concentracion
  public getAreasConcentracion(): Observable<any>{
    return this.http.get( this.baseUrl+'/areas-concentracion');
  }

  public getAreaConcentracionDetail(index: number){
    return this.http.get<AreaConcentracion>( this.baseUrl + `/area-concentracion/${index}`);
  }

  public postAreaConcentracion(area: AreaConcentracion){
    return this.http.post<AreaConcentracion>(this.baseUrl+'/area-concentracion',area);
  }

  public putAreaConcentracion(area: AreaConcentracion){
    return this.http.put<AreaConcentracion>(this.baseUrl+`/area-concentracionUpdate`,area);
  }

  public deleteAreaConcentracion(id: number){
    return this.http.delete<AreaConcentracion>(this.baseUrl+`/area-concentracion/?id=${id}`);
  }

  //REST Area de investigacion  
  public getAreasInvestigacion(): Observable<any>{
    return this.http.get<AreaInvestigacion>(this.baseUrl+'/areas-investigacion');
  }

  public getAreaInvestigacionDetail(index: number){
    return this.http.get<AreaInvestigacion>( this.baseUrl + `/area-investigacion/${index}`);
  }

  public postAreaInvestigacion(area: AreaInvestigacion){
    return this.http.post<AreaInvestigacion>(this.baseUrl+'/area-investigacion',area);
  }

  public putAreaInvestigacion(area: AreaInvestigacion){
    return this.http.put<AreaInvestigacion>(this.baseUrl+`/area-investigacionUpdate/`,area);
  }

  public deleteAreaInvestigacion(id: number){
    return this.http.delete<AreaInvestigacion>(this.baseUrl+`/area-investigacion?id=${id}`);
  }

  //REST Departamentos  
  public getDepartamentos(): Observable<any>{
    return this.http.get<Departamento>(this.baseUrl+'/departamentos');
  }

  public getDepartamentoDetail(index: number){
    return this.http.get<Departamento>( this.baseUrl + `/departamento/${index}`);
  }

  public postDepartamento(depto: Departamento){
    return this.http.post<Departamento>(this.baseUrl+'/departamento',depto);
  }

  public putDepartamento(depto: Departamento){
    return this.http.put<Departamento>(this.baseUrl+`/departamentoUpdate/`,depto);
  }

  public deleteDepartamento(id: number){
    return this.http.delete<Departamento>(this.baseUrl+`/departamento?id=${id}`);
  }

  //REST Divisiones  
  public getDivisiones(): Observable<any>{
    return this.http.get<Division>(this.baseUrl+'/divisiones');
  }

  public getDivisionDetail(index: number){
    return this.http.get<Division>( this.baseUrl + `/division/${index}`);
  }

  public postDivision(division: Division){
    return this.http.post<Division>(this.baseUrl+'/division',division);
  }

  public putDivision(division: Division){
    return this.http.put<Division>(this.baseUrl+`/divisionUpdate/`,division);
  }

  public deleteDivision(id: number){
    return this.http.delete<Division>(this.baseUrl+`/division?id=${id}`);
  }

  //REST Estado Academico  
  public getEstadosAcademicos(): Observable<any>{
    return this.http.get<EstadoAcademico>(this.baseUrl+'/estados');
  }

  public getEstadoAcademicoDetail(index: number){
    return this.http.get<EstadoAcademico>( this.baseUrl + `/estado/${index}`);
  }

  public postEstadosAcademico(estado: EstadoAcademico){
    return this.http.post<EstadoAcademico>(this.baseUrl+'/estado',estado);
  }

  public putEstadosAcademico(estado: EstadoAcademico){
    return this.http.put<EstadoAcademico>(this.baseUrl+`/estadoUpdate/`,estado);
  }

  public deleteEstadosAcademico(id: number){
    return this.http.delete<EstadoAcademico>(this.baseUrl+`/estado?id=${id}`);
  }

  //REST Estado Aspirante  
  public getEstadosAspirantes(): Observable<any>{
    return this.http.get<EstadoAspirante>(this.baseUrl+'/estados-aspirantes');
  }

  public getEstadoAspiranteDetail(index: number){
    return this.http.get<EstadoAspirante>( this.baseUrl + `/estado-aspirante/${index}`);
  }

  public postEstadoAspirante(estado: EstadoAspirante){
    return this.http.post<EstadoAspirante>(this.baseUrl+'/estado-aspirante',estado);
  }

  public putEstadoAspirante(estado: EstadoAspirante){
    return this.http.put<EstadoAspirante>(this.baseUrl+`/estado-aspiranteUpdate/`,estado);
  }

  public deleteEstadoAspirante(id: number){
    return this.http.delete<EstadoAspirante>(this.baseUrl+`/estado-aspirante?id=${id}`);
  }

  //REST Insituciones procedencia  
  public getInstituciones(): Observable<any>{
    return this.http.get<Institucion>(this.baseUrl+'/instituciones');
  }

  public getInstitucionDetail(index: number){
    return this.http.get<Institucion>( this.baseUrl + `/institucion/${index}`);
  }

  public postInstitucion(inst: Institucion){
    return this.http.post<Institucion>(this.baseUrl+'/institucion',inst);
  }

  public putInstitucion(inst: Institucion){
    return this.http.put<Institucion>(this.baseUrl+`/institucionUpdate/`,inst);
  }

  public deleteInstitucion(id: number){
    return this.http.delete<Institucion>(this.baseUrl+`/institucion?id=${id}`);
  }

  //REST LGAC  
  public getLGAC(): Observable<any> {
    return this.http.get<Institucion>(this.baseUrl + '/instituciones');
  }

  public getLGACDetail(index: number) {
    return this.http.get<Institucion>(this.baseUrl + `/institucion/${index}`);
  }

  public postLGAC(inst: Institucion) {
    return this.http.post<Institucion>(this.baseUrl + '/institucion', inst);
  }

  public putLGAC(inst: Institucion) {
    return this.http.put<Institucion>(this.baseUrl + `/institucionUpdate/`, inst);
  }

  public deleteLGAC(id: number) {
    return this.http.delete<Institucion>(this.baseUrl + `/institucion?id=${id}`);
  }

  //REST Nivel  
  public getNiveles(): Observable<any> {
    return this.http.get<Nivel>(this.baseUrl + '/niveles');
  }

  public getNivelDetail(index: number) {
    return this.http.get<Nivel>(this.baseUrl + `/nivel/${index}`);
  }

  public postNivel(nivel: Nivel) {
    return this.http.post<Nivel>(this.baseUrl + '/nivel', nivel);
  }

  public putNivel(nivel: Nivel) {
    return this.http.put<Nivel>(this.baseUrl + `/nivelUpdate/`, nivel);
  }

  public deleteNivel(id: number) {
    return this.http.delete<Nivel>(this.baseUrl + `/nivel?id=${id}`);
  }

  //REST Plan Estudios  
  public getPlanes(): Observable<any> {
    return this.http.get<PlanEstudios>(this.baseUrl + '/planes');
  }

  public getPlanDetail(index: number) {
    return this.http.get<PlanEstudios>(this.baseUrl + `/plan/${index}`);
  }

  public postPlan(plan: PlanEstudios) {
    return this.http.post<PlanEstudios>(this.baseUrl + '/plan', plan);
  }

  public putPlan(plan: PlanEstudios) {
    return this.http.put<PlanEstudios>(this.baseUrl + `/planUpdate/`, plan);
  }

  public deletePlan(id: number) {
    return this.http.delete<PlanEstudios>(this.baseUrl + `/plan?id=${id}`);
  }

  //REST Direccion

  public getDireccionAlumno(index : number) {
    return this.http.get<Direccion>(this.baseUrl + `/direccion-alumno/${index}` );
  }

  public postDireccion(direc: any) {
    return this.http.post<Direccion>(this.baseUrl + '/direccion', direc);
  }

  public putDireccion(direc: any) {
    return this.http.put<Direccion>(this.baseUrl + `/direccionUpdate/`, direc);
  }

  public deleteDireccion(id: number) {
    return this.http.delete<Direccion>(this.baseUrl + `/direccion?id=${id}`);
  }

  public deleteDireccionCoincidir(calle : string,numero : number, id: number) {
    return this.http.delete<Direccion>(this.baseUrl + `/direccion-coincidir?calle=${calle}&numero=${numero}&id=${id}`);
  }

  //REST Aspirantes

  public getAspirantes(): Observable<any> {
    return this.http.get<Aspirante>(this.baseUrl + '/aspirantes');
  }

  public getAspiranteDetail(index: number) {
    return this.http.get<Aspirante>(this.baseUrl + `/aspirante/${index}`);
  }

  public postAspirante(aspirante: any) {
    return this.http.post<Aspirante>(this.baseUrl + '/aspirante', aspirante);
  }

  public putAspirante(aspirante: Aspirante) {
    return this.http.put<Aspirante>(this.baseUrl + `/aspiranteUpdate/`, aspirante);
  }

  public deleteAspirante(id: number) {
    return this.http.delete<Aspirante>(this.baseUrl + `/aspirante?id=${id}`);
  }

  //REST Autores

  public getAutores(): Observable<any> {
    return this.http.get<Autor>(this.baseUrl + '/autores');
  }

  public getAutorDetail(index: number) {
    return this.http.get<Autor>(this.baseUrl + `/autor/${index}`);
  }

  public postAutor(autor: any) {
    return this.http.post<Autor>(this.baseUrl + '/autor', autor);
  }

  public putAutor(autor: any) {
    return this.http.put<Autor>(this.baseUrl + `/autorUpdate/`, autor);
  }

  public deleteAutor(id: number) {
    return this.http.delete<Autor>(this.baseUrl + `/autor?id=${id}`);
  }

  //REST grupo Autores

  public getGruposAutores(): Observable<any> {
    return this.http.get<GrupoAutores>(this.baseUrl + '/allGruposAutores');
  }

  public getGruposAutoresDetail(index: number) {
    return this.http.get<GrupoAutores>(this.baseUrl + `/allGruposAutores/${index}`);
  }

  public postGruposAutores(g_autor: any) {
    return this.http.post<GrupoAutores>(this.baseUrl + '/grupoAutores', g_autor);
  }

  public putGruposAutores(g_autor: GrupoAutores) {
    return this.http.put<GrupoAutores>(this.baseUrl + `/grupoAutoresUpdate/`, g_autor);
  }

  public deleteGruposAutores(id: number) {
    return this.http.delete<GrupoAutores>(this.baseUrl + `/grupoAutores?id=${id}`);
  }

  //REST Orden autor

  public getOrdenAutores(): Observable<any> {
    return this.http.get<OrdenAutor>(this.baseUrl + '/ordenAutores');
  }

  public getOrdenAutorDetail(index: number) {
    return this.http.get<OrdenAutor>(this.baseUrl + `/ordenAutor/${index}`);
  }

  public postOrdenAutor(orden: any) {
    return this.http.post<OrdenAutor>(this.baseUrl + '/ordenAutor', orden);
  }

  public putOrdenAutor(orden: OrdenAutor) {
    return this.http.put<OrdenAutor>(this.baseUrl + `/ordenAutorUpdate/`, orden);
  }

  public deleteOrdenAutor(id: number) {
    return this.http.delete<OrdenAutor>(this.baseUrl + `/ordenAutor?id=${id}`);
  }

  //REST tipos de clave autor

  public getTiposClavesAutor(): Observable<any> {
    return this.http.get<TipoClaveAutor>(this.baseUrl + '/tipoClaveAutores');
  }

  public getTipoClaveAutor(index: number) {
    return this.http.get<TipoClaveAutor>(this.baseUrl + `/tipoClaveAutores/${index}`);
  }

  public postTipoClaveAutor(tipo: any) {
    return this.http.post<TipoClaveAutor>(this.baseUrl + '/tipoClaveAutor', tipo);
  }

  public putTipoClaveAutor(tipo: TipoClaveAutor) {
    return this.http.put<TipoClaveAutor>(this.baseUrl + `/tipoClaveAutorUpdate/`, tipo);
  }

  public deleteTipoClaveAutor(id: number) {
    return this.http.delete<TipoClaveAutor>(this.baseUrl + `/tipoClaveAutor?id=${id}`);
  }

  //REST trimestres

  public getTrimestres(): Observable<any> {
    return this.http.get<Trimestre>(this.baseUrl + '/trimestres');
  }

  public getTrimestre(index: number) {
    return this.http.get<Trimestre>(this.baseUrl + `/trimestre/${index}`);
  }

  public postTrimestre(trimestre: any) {
    return this.http.post<Trimestre>(this.baseUrl + '/trimestre', trimestre);
  }

  public putTrimestre(trimestre: any) {
    return this.http.put<Trimestre>(this.baseUrl + `/trimestreUpdate/`, trimestre);
  }

  public deleteTrimestre(id: number) {
    return this.http.delete<Trimestre>(this.baseUrl + `/trimestre?id=${id}`);
  }

  //REST tipo produccion

  public getTiposProduccion(): Observable<any> {
    return this.http.get<TipoProduccion>(this.baseUrl + '/tipoProducciones');
  }

  public getTipoProduccion(index: number) {
    return this.http.get<TipoProduccion>(this.baseUrl + `/tipoProduccion/${index}`);
  }

  public postTipoProduccion(tipo: any) {
    return this.http.post<TipoProduccion>(this.baseUrl + '/tipoProduccion', tipo);
  }

  public putTipoProduccion(tipo: Autor) {
    return this.http.put<TipoProduccion>(this.baseUrl + `/tipoProduccionUpdate/`, tipo);
  }

  public deleteTipoProduccion(id: number) {
    return this.http.delete<TipoProduccion>(this.baseUrl + `/tipoProduccion?id=${id}`);
  }

  public upload2( file : File): Observable<any> {
    // creando formdata
    const formData = new FormData();

    //almacena el archivo como "file"
    formData.append("file", file);

    // http post request over api
    // con formData as req
    const req = new HttpRequest('POST',`${this.baseUrl}/produccion`,formData,{
      reportProgress:true,
      responseType: 'json'
    });
    return this.http.request(req);
  }

  ///REST Datamart
  public getAlumnosDatamart(): Observable<any> {
    return this.http.get<any>(this.baseUrl + '/datamart/alumnos');
  }

  public getAlumnoDetailDatamart(index: number) {
    return this.http.get<any>(this.baseUrl + `/datamart/alumno/${index}`);
  }

    //REST Autores Editores
    public getAutoresEditores(): Observable<any>{
      return this.http.get(this.baseUrl+'/AutoresEditores');
    }
  
    public getAutorEditorDetail(index: number){
      return this.http.get<AutorEditor>(this.baseUrl+`/AutorEditor/${index}`);
    }
  
    public findAutorEditor(autorEditor : any)
    {
      return this.http.get<AutorEditor>(this.baseUrl + 'AutorEditorFind', autorEditor);
    }
    public postAutorEditor(autorEditor: any){
      return this.http.post<AutorEditor>(this.baseUrl+'/AutorEditor',autorEditor);
    }
  
    public putAutorEditor(autorEditor : any){
      return this.http.put<AutorEditor>(this.baseUrl+`/AutorEditorUpdate`, autorEditor);
    }
  
    public deleteAutorEditor(id: number){
      return this.http.delete<AutorEditor>(this.baseUrl+`/AutorEditorDelete/?id=${id}`);
    }

    //REST Articulos
    public getArticulos(): Observable<any>{
      return this.http.get(this.baseUrl+'/Articulos');
    }
  
    public getArticuloDetail(index: number){
      return this.http.get<Articulo>(this.baseUrl+`/Articulo/${index}`);
    }
  
    public findArticulo(articulo : any) : Observable<any>
    {
      console.log(JSON.stringify(articulo));

      return this.http.post<Articulo> (this.baseUrl + '/ArticuloFind',articulo );
    }
    public postArticulo(articulo: any){
      return this.http.post<Articulo>(this.baseUrl+'/Articulo',articulo);
    }
  
    public putArticulo(articulo : any){
      return this.http.put<Articulo>(this.baseUrl+`/ArticuloUpdate`,articulo);
    }
  
    public deleteArticulo(id: number){
      return this.http.delete<Articulo>(this.baseUrl+`/ArticuloDelete/?id=${id}`);
    }
    //REST Revistas
    public getRevistas(): Observable<any>{
      return this.http.get(this.baseUrl+'/Revistas');
    }
  
    public getRevistaDetail(index: number){
      return this.http.get<Revista>(this.baseUrl+`/Revista/${index}`);
    }
    public findRevista(revista : any)
    {
      return this.http.post<Revista>(this.baseUrl + '/RevistaFind', revista);
    }
    public postRevista(revista: any){
      return this.http.post<Revista>(this.baseUrl+'/Revista',revista);
    }
  
    public putRevista(revista : any){
      return this.http.put<Revista>(this.baseUrl+`/RevistaUpdate`,revista);
    }
  
    public deleteRevista(id: number){
      return this.http.delete<Revista>(this.baseUrl+`/RevistaDelete/?id=${id}`);
    }
  //REST Libros
  
  public getLibros(): Observable<any>{
    return this.http.get(this.baseUrl+'/Libros');
  }
  
  public getLibroDetail(index: number){
    return this.http.get<Libro>(this.baseUrl+`/Libro/${index}`);
  }
  
  public findLibro(libro : any): Observable<any>
  {
    return this.http.post<Articulo>(this.baseUrl + '/LibroFind', libro);
  }
  public postLibro(libro: any){
    return this.http.post<Libro>(this.baseUrl+'/Libro',libro);
  }
  
  public putLibro(libro : any){
    return this.http.put<Libro>(this.baseUrl+`/LibroUpdate`,libro);
  }
  
  public deleteLibro(id: number){
    return this.http.delete<Libro>(this.baseUrl+`/LibroDelete/?id=${id}`);
  }
  
  //REST Innovacion
  
  public getInnovaciones(): Observable<any>{
    return this.http.get(this.baseUrl+'/Innovaciones');
  }
  
  public getInnovacionDetail(index: number){
    return this.http.get<Innovacion>(this.baseUrl+`/Innovacion/${index}`);
  }
  
  public findInnovacion(innovacion : any):Observable<any>
  {
    return this.http.post<Innovacion>(this.baseUrl + '/InnovacionFind', innovacion);
  }
  public postInnovacion(innovacion: any){
    return this.http.post<Innovacion>(this.baseUrl+'/Innovacion',innovacion);
  }
  
  public putInnovacion(innovacion : any){
    return this.http.put<Innovacion>(this.baseUrl+`/InnovacionUpdate`,innovacion);
  }
  
  public deleteInnovacion(id: number){
    return this.http.delete<Innovacion>(this.baseUrl+`/InnovacionDelete/?id=${id}`);
  }
  //REST Conferencia Presentación
  
  public getConferenciasPresentaciones(): Observable<any>{
    return this.http.get(this.baseUrl+'/ConferenciasPresentaciones');
  }
  
  public getConferenciaPresentacionDetail(index: number){
    return this.http.get<ConferenciaPresentacion>(this.baseUrl+`/ConferenciaPresentacion/${index}`);
  }
  
  public findConferenciaPresentacion(conferenciaPresentacion : any): Observable<any>
  {
    return this.http.post<ConferenciaPresentacion>(this.baseUrl + '/ConferenciaPresentacionFind', conferenciaPresentacion);
  }
  public postConferenciaPresentacion(conferenciaPresentacion: any){
    return this.http.post<ConferenciaPresentacion>(this.baseUrl+'/ConferenciaPresentacion',conferenciaPresentacion);
  }
  
  public putConferenciaPresentacion(conferenciaPresentacion : any){
    return this.http.put<ConferenciaPresentacion>(this.baseUrl+`/ConferenciaPresentacionUpdate`,conferenciaPresentacion);
  }
  
  public deleteConferenciaPresentacion(id: number){
    return this.http.delete<ConferenciaPresentacion>(this.baseUrl+`/ConferenciaPresentacionDelete/?id=${id}`);
  }
  // REST Desarrollo Tecnologico 
  public getDesarrollos(): Observable<any>{
    return this.http.get(this.baseUrl+'/Desarrollos');
  }
  
  public getDesarrolloDetail(index: number){
    return this.http.get<Desarrollo>(this.baseUrl+`/Desarrollo/${index}`);
  }
  
  public findDesarrollo(desarrollo : any): Observable<any>
  {
    return this.http.post<Desarrollo>(this.baseUrl + '/DesarrolloFind', desarrollo);
  }
  public postDesarrollo(desarrollo: any){
    return this.http.post<Desarrollo>(this.baseUrl+'/Desarrollo',desarrollo);
  }
  
  public putDesarrollo(desarrollo : any){
    return this.http.put<Desarrollo>(this.baseUrl+`/DesarrolloUpdate`, desarrollo);
  }
  
  public deleteDesarrollo(id: number){
    return this.http.delete<Desarrollo>(this.baseUrl+`/DesarrolloDelete/?id=${id}`);
  }
  //REST Rol de participacion
  public getRolDeParticipacion(): Observable<any>{
    return this.http.get(this.baseUrl+'/RolesParticipacion');
  }
  
  public getRolDeParticipacionDetail(index: number){
    return this.http.get<RolParticipacion>(this.baseUrl+`/RolParticipacion/${index}`);
  }
  
  public postRolParticipacion(rolDeParticipacion : any){
    return this.http.post<RolParticipacion>(this.baseUrl+'/RolParticipacion',rolDeParticipacion);
  }
  
  public putRolParticipacion(rolDeParticipacion : any){
    return this.http.put<RolParticipacion>(this.baseUrl+`/RevistaUpdate`,rolDeParticipacion);
  }
  
  public deleteRolParticipacion(id: number){
    return this.http.delete<RolParticipacion>(this.baseUrl+`/RolParticipacionDelete/?id=${id}`);
  }
  //REST  Tipo de desarrollo
  public getTipoDesarrollo(): Observable<any>{
    return this.http.get(this.baseUrl+'/TiposDesarrollo');
  }
  
  public getTipoDesarrolloDetail(index: number){
    return this.http.get<TipoDesarrollo>(this.baseUrl+`/TipoDesarrollo/${index}`);
  }
  
  public postTipoDesarrollo(tipoDesarrollo : any){
    return this.http.post<TipoDesarrollo>(this.baseUrl+'/TipoDesarrollo', tipoDesarrollo);
  }
  
  public putTipoDesarrollo( tipoDesarrollo : any){
    return this.http.put<TipoDesarrollo>(this.baseUrl+`/TipoDesarrolloUpdate`,tipoDesarrollo);
  }
  
  public deleteTipoDesarrollo(id: number){
    return this.http.delete<TipoDesarrollo>(this.baseUrl+`/TipoDesarrolloDelete/?id=${id}`);
  }
  //REST documento de respaldo
  public getDocumentosRespaldo(): Observable<any>{
    return this.http.get(this.baseUrl+'/DocumentosRespaldo');
  }
  
  public getDocumentoRespaldoDetail(index: number){
    return this.http.get<DocumentoRespaldo>(this.baseUrl+`/DocumentoRespaldo/${index}`);
  }
  
  public postDocumentoRespaldo(documentoRespaldo : any){
    return this.http.post<DocumentoRespaldo>(this.baseUrl+'/DocumentoRespaldo', documentoRespaldo);
  }
  
  public putDocumentoRespaldo( documentoRespaldo : any){
    return this.http.put<DocumentoRespaldo>(this.baseUrl+`/DocumentoRespaldoUpdate`,documentoRespaldo);
  }
  
  public deleteDocumentoRespaldo(id: number){
    return this.http.delete<DocumentoRespaldo>(this.baseUrl+`/DocumentoRespaldoDelete/?id=${id}`);
  }
  //REST Memoria
  public getMemorias(): Observable<any>{
    return this.http.get(this.baseUrl+'/Memorias');
  }
  
  public getMemoriaDetail(index: number){
    return this.http.get<Memoria>(this.baseUrl+`/Memoria/${index}`);
  }
  
  public findMemoria(memoria : any): Observable<any>
  {
    return this.http.post<Memoria>(this.baseUrl + '/MemoriaFind', memoria);
  }
  public postMemoria(memoria: any){
    return this.http.post<Memoria>(this.baseUrl+'/Memoria',memoria);
  }
  
  public putMemoria(memoria : any){
    return this.http.put<Memoria>(this.baseUrl+`/MemoriaUpdate`, memoria);
  }
  
  public deleteMemoria(id: number){
    return this.http.delete<Memoria>(this.baseUrl+`/MemoriaDelete/?id=${id}`);
  }
  
  //REST  REPORTE
  public getReportes(): Observable<any>{
    return this.http.get(this.baseUrl+'/Reportes');
  }
  
  public getReporteDetail(index: number){
    return this.http.get<Reporte>(this.baseUrl+`/Reporte/${index}`);
  }
  
  public findReporte(reporte : any): Observable<any>
  {
    return this.http.post<Reporte>(this.baseUrl + '/ReporteFind', reporte);
  }
  public postReporte(reporte: any){
    return this.http.post<Reporte>(this.baseUrl+'/Reporte',reporte);
  }
  
  public putReporte(reporte : any){
    return this.http.put<Reporte>(this.baseUrl+`/ReporteUpdate`, reporte);
  }
  
  public deleteReporte(id: number){
    return this.http.delete<Reporte>(this.baseUrl+`/ReporteDelete/?id=${id}`);
  }
  //REST INSTITUCIONES
  public getInstitucionesProduccionAcademica(): Observable<any>{
    return this.http.get(this.baseUrl+'/Instituciones2');
  }
  
  public getInstitucionProduccionAcademicaDetail(index: number){
    return this.http.get<InstitucionProduccionAcademica>(this.baseUrl+`/Institucion2/${index}`);
  }
  public postInstitucionProduccionAcademica(institucion: any){
    return this.http.post<InstitucionProduccionAcademica>(this.baseUrl+'/Institucion2',institucion);
  }
  
  public putInstitucionProduccionAcademica(institucion : any){
    return this.http.put<InstitucionProduccionAcademica>(this.baseUrl+`/Institucion2Update`, institucion);
  }
  
  public deleteInstitucionProduccionAcademica(id: number){
    return this.http.delete<InstitucionProduccionAcademica>(this.baseUrl+`/Institucion2Delete/?id=${id}`);
  }
  //REST ORIGEN REPORTE
  public getOrigenesReporte(): Observable<any>{
    return this.http.get(this.baseUrl+'/OrigenesReportes');
  }
  
  public getOrigenReporteDetail(index: number){
    return this.http.get<OrigenReporte>(this.baseUrl+`/OrigenReporte/${index}`);
  }
  public postOrigenReporte(origenReporte: any){
    return this.http.post<OrigenReporte>(this.baseUrl+'/OrigenReporte',origenReporte);
  }
  
  public putOrigenReporte(origenReporte : any){
    return this.http.put<OrigenReporte>(this.baseUrl+`/OrigenReporteUpdate`, origenReporte);
  }
  
  public deleteOrigenReporte(id: number){
    return this.http.delete<OrigenReporte>(this.baseUrl+`/OrigenReporteDelete/?id=${id}`);
  }
  //REST DOCUMENTOS DE TRABAJO Y RESEÑAS
  public getDocumentosReseñas(): Observable<any>{
    return this.http.get(this.baseUrl+'/DocumentosReseñas');
  }
  
  public getDocumentoReseñaDetail(index: number){
    return this.http.get<DocumentoReseña>(this.baseUrl+`/DocumentoReseña/${index}`);
  }
  
  public findDocumentoReseña(documentoReseña : any): Observable<any>
  {
    return this.http.post<DocumentoReseña>(this.baseUrl + '/DocumentoReseñaFind', documentoReseña);
  }
  public postDocumentoReseña(documentoReseña : any){
    return this.http.post<DocumentoReseña>(this.baseUrl+'/DocumentoReseña',documentoReseña);
  }
  
  public putDocumentoReseña(documentoReseña : any){
    return this.http.put<DocumentoReseña>(this.baseUrl+`/DocumentoReseñaUpdate`, documentoReseña);
  }
  
  public deleteDocumentoReseña(id: number){
    return this.http.delete<DocumentoReseña>(this.baseUrl+`/DocumentoReseñaDelete/?id=${id}`);
  }
  //REST Autor
  public getAutoresAutorProduccionAcademica(): Observable<any>{
    return this.http.get(this.baseUrl+'/AutoresProduccionAcademica');
  }
  
  public getAutorAutorProduccionAcademicaDetail(index: number){
    return this.http.get<AutorProduccionAcademica>(this.baseUrl+`/AutorProduccionAcademica/${index}`);
  }
  
  public findAutoAutorProduccionAcademica(autor : any)
  {
    return this.http.get<AutorProduccionAcademica>(this.baseUrl + 'AutorProduccionAcademicaFind', autor);
  }
  public postAutorAutorProduccionAcademica(autor : any){
    return this.http.post<AutorProduccionAcademica>(this.baseUrl+'/AutorProduccionAcademica',autor);
  }
  
  public putAutorAutorProduccionAcademica(autor : any){
    return this.http.put<AutorProduccionAcademica>(this.baseUrl+`/AutorProduccionAcademicaUpdate`, autor);
  }
  
  public deleteAutorAutorProduccionAcademica(id: number){
    return this.http.delete<AutorProduccionAcademica>(this.baseUrl+`/AutorProduccionAcademicaDelete/?id=${id}`);
  }
  //REST EDITOR
  public getEditores(): Observable<any>{
    return this.http.get(this.baseUrl+'/Editores');
  }
  
  public getEditorDetail(index: number){
    return this.http.get<Editor>(this.baseUrl+`/Editor/${index}`);
  }
  
  public findEditor(editor : any)
  {
    return this.http.get<Editor>(this.baseUrl + 'EditorFind', editor);
  }
  public postEditor(editor : any){
    return this.http.post<Editor>(this.baseUrl+'/Editor',editor);
  }
  
  public putEditor(editor : any){
    return this.http.put<Editor>(this.baseUrl+`/EditorUpdate`, editor);
  }
  
  public deleteEditor(id: number){
    return this.http.delete<Editor>(this.baseUrl+`/EditorDelete/?id=${id}`);
  }
  //REST ORDEN
  public getOrdenes(): Observable<any>{
    return this.http.get(this.baseUrl+'/Ordenes');
  }
  
  public getOrdenDetail(index: number){
    return this.http.get<Orden>(this.baseUrl+`/Orden/${index}`);
  }
  
  public findOrden(orden : any)
  {
    return this.http.get<Orden>(this.baseUrl + 'OrdenFind', orden);
  }
  public postOrden(orden : any){
    return this.http.post<Orden>(this.baseUrl+'/Orden',orden);
  }
  
  public putOrden(orden : any){
    return this.http.put<Orden>(this.baseUrl+`/OrdenUpdate`, orden);
  }
  
  public deleteOrden(id: number){
    return this.http.delete<Orden>(this.baseUrl+`/OrdenDelete/?id=${id}`);
  }
  
  //////////////////////Producciones Académicas //////////////////////////////////
  //REST Produccion Académica Articulos
  public getProduccionArticulo(): Observable<any>{
    return this.http.get(this.baseUrl+'/ProduccionesArticulos');
  }
  
  public getProduccionArticuloDetail(index: number){
    return this.http.get<ProduccionAcademicaArticulo>(this.baseUrl+`/ProduccionArticulo/${index}`);
  }
  public postProduccionArticulo(produccion: any){
    return this.http.post<ApiResult>(this.baseUrl+'/ProduccionArticulo',produccion);
  }
  
  public putProduccionArticulo(produccion : any){
    return this.http.put<ApiResult>(this.baseUrl+`/ProduccionArticuloUpdate`, produccion);
  }
  
  public deleteProduccionArticulo(id: number){
    return this.http.delete<ProduccionAcademicaArticulo>(this.baseUrl+`/ProduccionArticuloDelete/?id=${id}`);
  }
  //REST Produccion Académica Libros
  public getProduccionLibro(): Observable<any>{
    return this.http.get(this.baseUrl+'/ProduccionesLibros');
  }
  
  public getProduccionLibroDetail(index: number){
    return this.http.get<ProduccionAcademicaLibro>(this.baseUrl+`/ProduccionLibro/${index}`);
  }
  public postProduccionLibro(produccion: any){
    return this.http.post<ApiResult>(this.baseUrl+'/ProduccionLibro',produccion);
  }
  
  public putProduccionLibro(produccion : any){
    return this.http.put<ApiResult>(this.baseUrl+`/ProduccionLibroUpdate`, produccion);
  }
  
  public deleteProduccionLibro(id: number){
    return this.http.delete<ProduccionAcademicaLibro>(this.baseUrl+`/ProduccionLibroDelete/?id=${id}`);
  }
  
  //REST Produccion Académica Innovacion
  public getProduccionInnovacion(): Observable<any>{
    return this.http.get(this.baseUrl+'/ProduccionesInnovaciones');
  }
  
  public getProduccionInnovacionDetail(index: number){
    return this.http.get<ProduccionAcademicaInnovacion>(this.baseUrl+`/ProduccionInnovacion/${index}`);
  }
  public postProduccionInnovacion(produccion: any){
    return this.http.post<ApiResult>(this.baseUrl+'/ProduccionInnovacion',produccion);
  }
  
  public putProduccionInnovacion(produccion : any){
    return this.http.put<ApiResult>(this.baseUrl+`/ProduccionInnovacionUpdate`, produccion);
  }
  
  public deleteProduccionInnovacion(id: number){
    return this.http.delete<ProduccionAcademicaInnovacion>(this.baseUrl+`/ProduccionInnovacionDelete/?id=${id}`);
  }
  
  //REST Produccion Académica Desarrollo Tecnólogico
  public getProduccionDesarrollo(): Observable<any>{
    return this.http.get(this.baseUrl+'/ProduccionesDesarrollos');
  }
  
  public getProduccionDesarrolloDetail(index: number){
    return this.http.get<ProduccionAcademicaDesarrollo>(this.baseUrl+`/ProduccionDesarrollo/${index}`);
  }
  public postProduccionDesarrollo(produccion: any){
    return this.http.post<ApiResult>(this.baseUrl+'/ProduccionDesarrollo',produccion);
  }
  
  public putProduccionDesarrollo(produccion : any){
    return this.http.put<ApiResult>(this.baseUrl+`/ProduccionDesarrolloUpdate`, produccion);
  }
  
  public deleteProduccionDesarrollo(id: number){
    return this.http.delete<ProduccionAcademicaDesarrollo>(this.baseUrl+`/ProduccionDesarrolloDelete/?id=${id}`);
  }
  
  //REST Produccion Académica Reportes
  public getProduccionReportes(): Observable<any>{
    return this.http.get(this.baseUrl+'/ProduccionesReportes');
  }
  
  public getProduccionReporteDetail(index: number){
    return this.http.get<ProduccionAcademicaReporte>(this.baseUrl+`/ProduccionReporte/${index}`);
  }
  public postProduccionReporte(produccion: any){
    return this.http.post<ApiResult>(this.baseUrl+'/ProduccionReporte',produccion);
  }
  
  public putProduccionReporte(produccion : any){
    return this.http.put<ApiResult>(this.baseUrl+`/ProduccionReporteUpdate`, produccion);
  }
  
  public deleteProduccionReporte(id: number){
    return this.http.delete<ProduccionAcademicaReporte>(this.baseUrl+`/ProduccionReporteDelete/?id=${id}`);
  }
  
  //REST Produccion Académica Documentos de trabajo y reseñas
  public getProduccionDocumentosReseñas(): Observable<any>{
    return this.http.get(this.baseUrl+'/ProduccionesDocumentosReseñas');
  }
  
  public getProduccionDocumentoReseñaDetail(index: number){
    return this.http.get<ProduccionAcademicaDocumentosReseñas>(this.baseUrl+`/ProduccionDocumentoReseña/${index}`);
  }
  public postProduccionDocumentoReseña(produccion: any){
    return this.http.post<ApiResult>(this.baseUrl+'/ProduccionDocumentoReseña',produccion);
  }
  
  public putProduccionDocumentoReseña(produccion : any){
    return this.http.put<ApiResult>(this.baseUrl+`/ProduccionDocumentoReseñaUpdate`, produccion);
  }
  
  public deleteProduccionDocumentoReseña(id: number){
    return this.http.delete<ProduccionAcademicaDocumentosReseñas>(this.baseUrl+`/ProduccionDocumentoReseñaDelete/?id=${id}`);
  }
  
  //REST Produccion Académica Memorias
  public getProduccionMemorias(): Observable<any>{
    return this.http.get(this.baseUrl+'/ProduccionesMemorias');
  }
  
  public getProduccionMemoriaDetail(index: number){
    return this.http.get<ProduccionAcademicaMemoria>(this.baseUrl+`/ProduccionMemoria/${index}`);
  }
  public postProduccionMemoria(produccion: any){
    return this.http.post<ApiResult>(this.baseUrl+'/ProduccionMemoria',produccion);
  }
  
  public putProduccionMemoria(produccion : any){
    return this.http.put<ApiResult>(this.baseUrl+`/ProduccionMemoriaUpdate`, produccion);
  }
  
  public deleteProduccionMemoria(id: number){
    return this.http.delete<ProduccionAcademicaMemoria>(this.baseUrl+`/ProduccionMemoriaDelete/?id=${id}`);
  }
  
  //REST Produccion Académica Conferencias Presentaciones
  public getProduccionConferenciasPresentaciones(): Observable<any>{
    return this.http.get(this.baseUrl+'/ProduccionesConferenciasPresentaciones');
  }
  
  public getProduccionConferenciaPresentacionDetail(index: number){
    return this.http.get<ProduccionAcademicaConferenciaPresetacion>(this.baseUrl+`/ProduccionConferenciaPresentacion/${index}`);
  }
  public postProduccionConferenciaPresentacion(produccion: any){
    return this.http.post<ApiResult>(this.baseUrl+'/ProduccionConferenciaPresentacion',produccion);
  }
  
  public putProduccionConferenciaPresentacion(produccion : any){
    return this.http.put<ApiResult>(this.baseUrl+`/ProduccionConferenciaPresentacionUpdate`, produccion);
  }
  
  public deleteProduccionConferenciaPresentacion(id: number){
    return this.http.delete<ProduccionAcademicaConferenciaPresetacion>(this.baseUrl+`/ProduccionConferenciaPresentacionDelete/?id=${id}`);
  }
  
  ////////////////Datamart//////////////////////////
  //REST Produccion academica datamart
  public getProduccionesAcademicasDatamart(): Observable<any>{
    return this.http.get(this.baseUrl+'/ProduccionesAcemicasDatamart');
  }
  
  public getProduccionAcademicaDatamart(index: number){
    return this.http.get<ProduccionAcademicaDatamart>(this.baseUrl+`/ProduccionAcademicaDatamart/${index}`);
  }
  public postProduccionAcademicaDatamart(produccion: any){
    return this.http.post<ProduccionAcademicaDatamart>(this.baseUrl+'/ProduccionAcademicaDatamart',produccion);
  }
  
  public putProduccionAcademicaDatamart(produccion : any){
    return this.http.put<ProduccionAcademicaDatamart>(this.baseUrl+`/ProduccionAcademicaDatamartUpdate`, produccion);
  }
  
  public deleteProduccionAcademicaDatamart(id: number){
    return this.http.delete<ProduccionAcademicaDatamart>(this.baseUrl+`/ProduccionAcademicaDatamartDelete/?id=${id}`);
  }
  //REST Autores Editores Datamart
  public getAutoresEditoresDatamart(): Observable<any>{
    return this.http.get(this.baseUrl+'/AutoresEditoresDatamart');
  }
  
  public getAutorEditorDatamart(index: number){
    return this.http.get<AutorEditorDatamartProduccion>(this.baseUrl+`/AutorEditorDatamart/${index}`);
  }
  public postAutorEditorDatamart(autorEditor: any){
    return this.http.post<AutorEditorDatamartProduccion>(this.baseUrl+'/AutorEditorDatamart',autorEditor);
  }
  
  public putAutorEditorDatamart(autorEditor : any){
    return this.http.put<AutorEditorDatamartProduccion>(this.baseUrl+`/AutorEditorUpdate`, autorEditor);
  }
  
  public deleteAutorEditorDatamart(id: number){
    return this.http.delete<AutorEditorDatamartProduccion>(this.baseUrl+`/AutorEditorDelete/?id=${id}`);
  }
  public findAutorEditorDatamart(autorEditor: any){
    return this.http.post<AutorEditorDatamartProduccion>(this.baseUrl+'/autorEditorDatamartFind',autorEditor);
  }

  //REST producciones generales
  public getProduccionesGeneralesDatamart(): Observable<any>{
    return this.http.get(this.baseUrl+'/ProduccionesGenerales');
  }
  
  public getProduccionGeneralDatamart(index: number){
    return this.http.get<ProduccionGeneralDatamart>(this.baseUrl+`/ProduccionGeneral/${index}`);
  }
  public postProduccionGeneralDatamart(produccion: any){
    return this.http.post<ProduccionGeneralDatamart>(this.baseUrl+'/ProduccionGeneral',produccion);
  }
  
  public putProduccionGeneralDatamart(produccion : any){
    return this.http.put<ProduccionGeneralDatamart>(this.baseUrl+`/ProduccionGeneralUpdate`, produccion);
  }
  
  public deleteProduccionGeneralDatamart(id: number){
    return this.http.delete<ProduccionGeneralDatamart>(this.baseUrl+`/ProduccionGeneralDelete/?id=${id}`);
  }
  public findProduccionGeneralDatamart(produccion: any){
    return this.http.post<ProduccionGeneralDatamart>(this.baseUrl+'/ProduccionGeneralFind',produccion);
  }
  
  //REST Autor Editor Cuenta
  public getAutoresEditoresCuentaDatamart(): Observable<any>{
    return this.http.get(this.baseUrl+'/AutorEditorCuentasProducciones');
  }
  public getAutorEditorCuentaDatamart(index: number){
    return this.http.get<AutorEditorCuentaProduccionDatamart>(this.baseUrl+`/AutorEditorCuentaProduccion/${index}`);
  }
  public findAutorEditorCuentaDatamart(produccion: any){
    return this.http.post<AutorEditorCuentaProduccionDatamart>(this.baseUrl+'/AutorEditorCuentaProduccionFind',produccion);
  }
  //REST DE INDICADORES
  //Cuentas producciones
  public getCuentasProducciones(): Observable<CuentaProduccionDatamart[]> {
    return this.http.get<CuentaProduccionDatamart[]>(this.baseUrl+'/CuentasProducciones');
  }
  //FrecuenciaProducciones
  public getFrecuenciaProducciones(): Observable<any> {
    return this.http.get<FrecuenciaProduccionDatamart[]>(this.baseUrl+'/FrecuenciaProducciones');
  }
  public getFrecuenciaProduccionesANO(ano : number): Observable<any> {
    return this.http.get<FrecuenciaProduccionDatamart[]>(this.baseUrl+`/FrecuenciaProduccionesAno/${ano}`);
  }
  public getFrecuenciaProduccionesAnos(): Observable<any>
  {
    return this.http.get<number>(this.baseUrl+`/FrecuenciaProduccionesAnos`);
  }
  //Profesores Alumnos Principales

  public getProfesorAlumnoPrincipal(): Observable<any>
  {
    return this.http.get<ProfesorAlumnoPrincipalDatamart[]>(this.baseUrl+'/ProfesoresAlumnosPrincipales');
  }
  // REST Palaras clave
  public getPalabrasClabe(): Observable<any>{
    return this.http.get(this.baseUrl+'/PalabrasClave');
  }
  
  public getPalabraClaveDetail(index: number){
    return this.http.get<PalabrasClave>(this.baseUrl+`/PalabraClave/${index}`);
  }
  public postPalabraClave(palabraClave: any){
    return this.http.post<PalabrasClave>(this.baseUrl+'/PalabraClave',palabraClave);
  }
  
  public putPalabraClave(palabraClave : any){
    return this.http.put<PalabrasClave>(this.baseUrl+`/PalabraClaveUpdate`, palabraClave);
  }
  
  public deletePalabraClave(id: number){
    return this.http.delete<PalabrasClave>(this.baseUrl+`/PalabraClaveDelete/?id=${id}`);
  }
  
  

}
