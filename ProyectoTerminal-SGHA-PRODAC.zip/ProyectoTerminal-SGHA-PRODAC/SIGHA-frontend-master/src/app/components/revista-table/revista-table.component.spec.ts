import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RevistaTableComponent } from './revista-table.component';

describe('RevistaTableComponent', () => {
  let component: RevistaTableComponent;
  let fixture: ComponentFixture<RevistaTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RevistaTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RevistaTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
