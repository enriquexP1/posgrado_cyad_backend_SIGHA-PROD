import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TooltipComponent } from '@angular/material/tooltip';
import { Router } from '@angular/router';
import { pairs } from 'rxjs';
import { AutorEditor } from 'src/app/interfaces/autor-editor';
import { Orden } from 'src/app/interfaces/orden';
import { CyadService } from 'src/app/service/cyad.service';
import { MatDialog } from '@angular/material/dialog';
import { AutorDetailComponent } from '../autor-detail/autor-detail.component';
import { ApiResult } from 'src/app/interfaces/api-result';
import { ConferenciaPresentacion } from 'src/app/interfaces/conferencia-presentacion';

@Component({
  selector: 'app-conferencia-presentacion-register',
  templateUrl: './conferencia-presentacion-register.component.html',
  styleUrls: ['./conferencia-presentacion-register.component.scss']
})
export class ConferenciaPresentacionRegisterComponent implements OnInit {

  firstFormGroup!: FormGroup;
  secondFormGroup!: FormGroup;
  /**listas */
  listAutores !: AutorEditor[];


  public grupo_autores?: any = [];
  autores_select !: any[];
  public filteredAutores?: AutorEditor[];
  constructor(private cyadService: CyadService, private route: Router, private formBuilder: FormBuilder,private dialog: MatDialog) { }

  ngOnInit(): void {
    this.firstFormGroup = this.formBuilder.group({
      conferencia_presentacion: ['', Validators.required],
      titulo: ['', Validators.required],
      evento: ['',Validators.required],
      fecha_presentacion: ['', Validators.required],
      ciudad: ['', Validators.required],
      pais: ['', Validators.required]
    
    });
    this.secondFormGroup = this.formBuilder.group({
      autores: this.formBuilder.array([])
    });


    /**cargando listas */
    this.cyadService.getAutoresEditores().subscribe({
      next: (res) => {
        this.listAutores = res;
        this.filteredAutores = this.listAutores;
      }
    });


  }

  /**agregar campos de forma dinamica */
  get autores() {
    return this.secondFormGroup.get('autores') as FormArray;
  }




  agregarAutor() {
    const autoresFormGroup = this.formBuilder.group({
      autor: ['', Validators.required]
    });
    this.autores.push(autoresFormGroup);
  }


  removerAutor(indice: number) {
    this.autores.removeAt(indice);
  }

  refresh() {
    this.autores.controls.splice(0, this.autores.length);
  }

  onKey(value: EventTarget | null){

    let filterValue: string;
    filterValue = (value as HTMLInputElement).value;
    console.log(filterValue);
    this.filteredAutores = this.listAutores.filter(autor => autor.nombre.concat(autor.primerApellido, autor.segundoApellido).toLowerCase().includes(filterValue.toLowerCase()));
  } 


  addProduccion() {

    if (this.firstFormGroup.valid && this.secondFormGroup.valid) {
      /* Creamos los objetos que llenamos en el formgroup */
      let conferencia_presentacion: ConferenciaPresentacion;

      let revistaId: Number;

       // Recuperando
       let conferencia_presentacionBool: boolean;
       if (this.firstFormGroup.controls['conferencia_presentacion'].value == "conferencia") conferencia_presentacionBool = false;
       else { conferencia_presentacionBool = true };



       conferencia_presentacion= {
        // obtenemos los datos requeridos de la interface articulo desde los formgroups
        // estos datos se obtienen a partir de su formControlName
        conferencia_presentacion: conferencia_presentacionBool,
        titulo: this.firstFormGroup.controls['titulo'].value,
        evento: this.firstFormGroup.controls['evento'].value,
        fecha_presentacion: this.firstFormGroup.controls['fecha_presentacion'].value,
        ciudad: this.firstFormGroup.controls['ciudad'].value,
        pais: this.firstFormGroup.controls['pais'].value
      
      }
      console.log(conferencia_presentacion.evento);
      this.grupo_autores = this.secondFormGroup.controls['autores'].value;



      this.cyadService.postConferenciaPresentacion(conferencia_presentacion).subscribe({
        next: result => {
          this.buscarConferenciaPresentacion(conferencia_presentacion);
        },
        error: error => console.log(error)
      });
    }

  }

  buscarConferenciaPresentacion(conferencia_presentacion: ConferenciaPresentacion) {
    this.cyadService.findConferenciaPresentacion(conferencia_presentacion).subscribe({
      next: result2 => {
        console.log("Result was the following " + result2.id);
        
          this.addProducciones(result2.id);
        
      },
      error: error => console.log(error)
    })
  }
 

  addProducciones(ConferenciaPresentacionId: number) {
    if (ConferenciaPresentacionId == null) {
      return;
    }
    for (let i = 0; i < this.autores.length; i++) {
      const item = this.autores.at(i).value;
      let produccion;
      produccion = {
        
        conferenciaPresentacion: {
          id: ConferenciaPresentacionId
        },
        autor: {
          id: item.autor
        }
        
      }

      this.cyadService.postProduccionConferenciaPresentacion(produccion).subscribe({
        next: result => {
          let res:ApiResult;
          res = result; 
          if(res.response == true)
          {
            alert("EXITO AL REGISTRAR LA PRODUCCIÓN")
            window.location.reload();
          }
          else
          {
            alert(res.message);
          }
        },
        error: error => alert('Error al resgistrar Conferencia/Presentación')
      });
    }
  }
  openDialog(){
    const dialogRef =  this.dialog.open(AutorDetailComponent);
    dialogRef.afterClosed().subscribe(
      val =>{
        if(val === 'save'){
          /**cargando listas */
          this.cyadService.getAutoresEditores().subscribe({
            next:(res)=>{
              this.listAutores = res;
            }

          });
        }
        this.agregarAutor();
      }
    );

  }
}
