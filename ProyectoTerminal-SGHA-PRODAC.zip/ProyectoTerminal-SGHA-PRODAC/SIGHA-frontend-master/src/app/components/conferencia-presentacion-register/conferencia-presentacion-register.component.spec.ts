import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConferenciaPresentacionRegisterComponent } from './conferencia-presentacion-register.component';

describe('ConferenciaPresentacionRegisterComponent', () => {
  let component: ConferenciaPresentacionRegisterComponent;
  let fixture: ComponentFixture<ConferenciaPresentacionRegisterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConferenciaPresentacionRegisterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConferenciaPresentacionRegisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
