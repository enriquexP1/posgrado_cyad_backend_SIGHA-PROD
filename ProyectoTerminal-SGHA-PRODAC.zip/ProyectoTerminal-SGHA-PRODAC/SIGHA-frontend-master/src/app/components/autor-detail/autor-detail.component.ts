import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CyadService } from 'src/app/service/cyad.service';

import { AutorEditor } from "src/app/interfaces/autor-editor";


@Component({
  selector: 'app-autor-detail',
  templateUrl: './autor-detail.component.html',
  styleUrls: ['./autor-detail.component.scss']
})
export class AutorDetailComponent implements OnInit {

  areaForm!: FormGroup;
  title: string = "Nuevo autor";
  actionBtn: string = "Guardar";

  

  constructor(
    private cyadService: CyadService,
    private formBuilder: FormBuilder,
    public dialogRef: MatDialogRef<AutorDetailComponent>,
    @Inject(MAT_DIALOG_DATA) public editData: AutorEditor,
  ) { }

  ngOnInit(): void {
    /*Agregando validaciones a los input*/
    this.areaForm = this.formBuilder.group({
      id: ['', Validators.required],
      nombre: ['', Validators.required],
      ap_paterno: ['', Validators.required],
      ap_materno: ['', Validators.required],
      profesor_alumno: ['', Validators.required],
      autor_editor: ['', Validators.required],
      editorial: ['']
    });

    /*Al iniciar el cuadro de dialogo
    si se tarta de una edición*/
    if (this.editData) {

      let profesorAlumno: string, autorEditor: string
      profesorAlumno = this.editData.profesor_alumno ? "Profesor" : "Alumno";
      autorEditor = this.editData.autorEditor ? "Autor" : "Editor";
      this.title = "Actualizar autor";
      this.actionBtn = "Actualizar";
      this.areaForm.controls['id'].setValue(this.editData.id);
      this.areaForm.controls['nombre'].setValue(this.editData.nombre);
      this.areaForm.controls['ap_paterno'].setValue(this.editData.primerApellido);
      this.areaForm.controls['ap_materno'].setValue(this.editData.segundoApellido);
      this.areaForm.controls['profesor_alumno'].setValue(profesorAlumno);
      this.areaForm.controls['autor_editor'].setValue(autorEditor);
      this.areaForm.controls['editorial'].setValue(this.editData.editorial);
    }

    /*El id es un campo gestionado por el servicio*/
    this.areaForm.controls['id'].disable();



  }

  submitAutor() {
    if (this.actionBtn == "Guardar") {
      this.addAutor();
    } else if (this.actionBtn == "Actualizar") {
      this.updateAutor();
    }
  }
  onNoClick(): void {
    this.dialogRef.close();
  }

  addAutor() {
    if (!this.editData) {
      if (this.areaForm.valid) {

        // Recuperando
        let profesorAlumno: boolean, autorEditor: boolean
        if (this.areaForm.controls['profesor_alumno'].value == "Profesor") profesorAlumno = false;
        else { profesorAlumno = true };

        if (this.areaForm.controls['autor_editor'].value == "Autor") autorEditor = false;
        else { autorEditor = true };

        /**estructura */
        let autor: AutorEditor;

        autor = {
          nombre: this.areaForm.controls['nombre'].value,
          primerApellido: this.areaForm.controls['ap_paterno'].value,
          segundoApellido: this.areaForm.controls['ap_materno'].value,
          profesor_alumno: profesorAlumno,
          autorEditor: autorEditor,
          editorial: this.areaForm.controls['editorial'].value
        }


        console.log(autor);
        /**llamada al servicio */
        this.cyadService.postAutorEditor(autor)
          .subscribe({
            next: (res) => {
              console.log(res);
              alert("Autor add successfully");
              this.areaForm.reset();
              this.dialogRef.close('save');
            },
            error: (err) => {
              alert("Error while adding the autor " + err);
            }
          })
      }
    }
    else {
      this.areaForm.controls['id'].enable();//habilita input
      this.updateAutor();
    }
  }

  updateAutor() {

    // Recuperando
    let profesorAlumno: boolean, autorEditor: boolean
    if (this.areaForm.controls['profesor_alumno'].value == "Profesor") profesorAlumno = false;
    else { profesorAlumno = true };

    if (this.areaForm.controls['autor_editor'].value == "Autor") autorEditor = false;
    else { autorEditor = true };

    /**estructura */
    let autor: AutorEditor;

    autor = {
      id: this.editData.id,
      nombre: this.areaForm.controls['nombre'].value,
      primerApellido: this.areaForm.controls['ap_paterno'].value,
      segundoApellido: this.areaForm.controls['ap_materno'].value,
      profesor_alumno: profesorAlumno,
      autorEditor: autorEditor,
      editorial: this.areaForm.controls['editorial'].value
    }

    this.cyadService.putAutorEditor(autor)
      .subscribe({
        next: (res) => {
          console.log(res);
          alert("Autor update succesfully");
          this.areaForm.reset();
          this.dialogRef.close('update');
        },
        error: () => {
          alert("error while update the autor");
        }

      })
  }

}
