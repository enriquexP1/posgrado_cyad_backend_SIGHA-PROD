import { Component, OnInit } from '@angular/core';
import {Chart, registerables} from "chart.js";
import { AutorEditorCuentaProduccionDatamart } from 'src/app/interfaces/autor-editor-cuenta-produccion-datamart';
import { CyadService } from 'src/app/service/cyad.service';

@Component({
  selector: 'app-autor-editor-cuenta-produccion',
  templateUrl: './autor-editor-cuenta-produccion.component.html',
  styleUrls: ['./autor-editor-cuenta-produccion.component.scss']
})
export class AutorEditorCuentaProduccionComponent implements OnInit {
  public chart?: Chart;
  public frecuenciaAutores: Map<Number, String>= new Map();
  public filteredAutores: Map<Number, String> = this.frecuenciaAutores;
  public listaAutores: Array<AutorEditorCuentaProduccionDatamart> = [];
  constructor(private service: CyadService) { 
    Chart.register(...registerables);
  }

  ngOnInit(): void {
    this.loadAutores();
    this.onChange(1);
  }
  onChange(newValue: number){
    console.log("Llamada a onchange " + newValue)
    this.service.getAutoresEditoresCuentaDatamart().subscribe({
      next: result =>{
        let madeList: AutorEditorCuentaProduccionDatamart[] = result;
        this.createChart(madeList, newValue);
      }
    })
  }
  loadAutores(){
    this.service.getAutoresEditoresCuentaDatamart().subscribe({
      next: result => {
        let fixedResult: AutorEditorCuentaProduccionDatamart[] = result;
        if(fixedResult != null){
          fixedResult.forEach(element => {
              let nombreCompleto: string;
              let key: number
              nombreCompleto = element.nombre + " " + element.apellidoPaterno + " " + element.apellidoMaterno
              key = element.id
              console.log("id.-" +key + ": " + nombreCompleto);
              this.frecuenciaAutores.set(key, nombreCompleto);
          })
        }
        console.log(this.frecuenciaAutores);
        console.log(fixedResult);

      },
      error: error => console.error(error)
    });
  }

  onKey(value: EventTarget | null){

    let filterValue: string;
    filterValue = (value as HTMLInputElement).value;
    console.log(filterValue);
    this.filteredAutores = this.search(filterValue.toLowerCase());
  } 
  
  search(value: string): Map<Number, String>{

    let filteredMap = new Map([...this.frecuenciaAutores].filter(([k, v]) => v.toLowerCase().includes(value)));
    console.log(filteredMap)
    return filteredMap;
  }

createChart(listaAutores: AutorEditorCuentaProduccionDatamart[], id: number ){
    let autor = listaAutores[id-1];
    if(this.chart){
      this.chart.destroy();
    }
    //let nombre = this.frecuenciaAutores.get(id);
    //if(typeof(nombre) == undefined) nombre = "ERROR";
    console.log(autor)
    this.chart = new Chart("ChartAutorEditor", {
      type: 'bar',
      data: {
        labels: ['Articulo','Conferencia','Desarrollo tecnólogico', 'Documentos de trabajo', 'Innovación','Libro','Memoria', 'Presentación', 'Reporte','Reseña'],
        datasets:[{
          label: autor.nombre + " " + autor.apellidoPaterno + " " + autor.apellidoMaterno,
          data: [autor.articulo, autor.conferencia, autor.desarrollo, autor.documento,
          autor.innovacion, autor.libro, autor.memoria, autor.presentacion, autor.reporte, autor.resena],
          backgroundColor: [
            'rgba(255, 99, 132, 0.2)',
            'rgba(255, 159, 64, 0.2)',
            'rgba(255, 205, 86, 0.2)',
            'rgba(75, 192, 192, 0.2)',
            'rgba(54, 162, 235, 0.2)',
            'rgba(153, 102, 255, 0.2)',
            'rgba(201, 203, 207, 0.2)',
            'rgba(57, 13, 56, 0.2)',
            'rgba(210, 300, 90, 0.2)',
            'rgba(125, 192, 76, 0.2)'
          
          ],
          borderColor: [
            'rgb(255, 99, 132)',
            'rgb(255, 159, 64)',
            'rgb(255, 205, 86)',
            'rgb(75, 192, 192)',
            'rgb(54, 162, 235)',
            'rgb(153, 102, 255)',
            'rgb(201, 203, 207)',
            'rgb(57, 13, 56)',
            'rgb(210, 300, 90)',
            'rgb(125, 192, 76)'
          ],
          borderWidth: 1
        }]
      },
      options:{
        aspectRatio: 2,
        maintainAspectRatio: true,
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
      
    })

}
}

