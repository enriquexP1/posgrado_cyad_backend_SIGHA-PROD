import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AutorEditorCuentaProduccionComponent } from './autor-editor-cuenta-produccion.component';

describe('AutorEditorCuentaProduccionComponent', () => {
  let component: AutorEditorCuentaProduccionComponent;
  let fixture: ComponentFixture<AutorEditorCuentaProduccionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AutorEditorCuentaProduccionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AutorEditorCuentaProduccionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
