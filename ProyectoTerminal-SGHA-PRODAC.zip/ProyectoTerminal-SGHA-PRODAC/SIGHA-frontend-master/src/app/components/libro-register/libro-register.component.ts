import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TooltipComponent } from '@angular/material/tooltip';
import { Router } from '@angular/router';
import { pairs } from 'rxjs';
import { AutorEditor } from 'src/app/interfaces/autor-editor';
import { Orden } from 'src/app/interfaces/orden';
import { CyadService } from 'src/app/service/cyad.service';

import { ProduccionAcademicaLibro } from 'src/app/interfaces/produccion-academica-libro';
import { Libro } from 'src/app/interfaces/libro';
import { MatDialog } from '@angular/material/dialog';
import { AutorDetailComponent } from '../autor-detail/autor-detail.component';
import { ApiResult } from 'src/app/interfaces/api-result';

@Component({
  selector: 'app-libro-register',
  templateUrl: './libro-register.component.html',
  styleUrls: ['./libro-register.component.scss']
})
export class LibroRegisterComponent implements OnInit {

  firstFormGroup!: FormGroup;
  secondFormGroup!: FormGroup;
  /**listas */
  listAutores !: AutorEditor[];
  listOrden !: Orden[];

  public grupo_autores?: any = [];
  public orden?: Orden;
  autores_select !: any[];
  public filteredAutores?: AutorEditor[];

  constructor(private cyadService: CyadService, private route: Router, private formBuilder: FormBuilder,private dialog: MatDialog) { }

  ngOnInit(): void {
    this.firstFormGroup = this.formBuilder.group({
      titulo: ['', Validators.required],
      isbn: ['', Validators.required],
      doi: ['', Validators.required],
      fecha_publicacion: ['', Validators.required],
      numero_paginas: ['', Validators.required],
      editorial: ['', Validators.required],
      numero_edicion: ['', Validators.required],
      ano_edicion: ['', Validators.required],
      volumen: ['', Validators.required],
      tomo: ['', Validators.required],
      titulo_traducido: ['', Validators.required],
      idioma_traducido: ['', Validators.required],
      pais: ['', Validators.required],
      idioma: ['', Validators.required]

    });
    this.secondFormGroup = this.formBuilder.group({
      autores: this.formBuilder.array([])
    });


    /**cargando listas */
    this.cyadService.getAutoresEditores().subscribe({
      next: (res) => {
        this.listAutores = res;
        this.filteredAutores = this.listAutores;
        console.log(this.listAutores);
      }
    });


    this.cyadService.getOrdenes().subscribe({
      next: (res) => {
        this.listOrden = res;
      }
    });
  }

  /**agregar campos de forma dinamica */
  get autores() {
    return this.secondFormGroup.get('autores') as FormArray;
  }




  agregarAutor() {
    const autoresFormGroup = this.formBuilder.group({
      autor: ['', Validators.required],
      orden: ['', Validators.required]
    });
    this.autores.push(autoresFormGroup);
  }


  removerAutor(indice: number) {
    this.autores.removeAt(indice);
  }

  refresh() {
    this.autores.controls.splice(0, this.autores.length);
  }



  addProduccion() {

    if (this.firstFormGroup.valid && this.secondFormGroup.valid) {
      /* Creamos los objetos que llenamos en el formgroup */
      let libro: Libro;

      let revistaId: Number;




      libro = {
        // obtenemos los datos requeridos de la interface articulo desde los formgroups
        // estos datos se obtienen a partir de su formControlName
        titulo: this.firstFormGroup.controls['titulo'].value,
        isbn: this.firstFormGroup.controls['isbn'].value,
        doi: this.firstFormGroup.controls['doi'].value,
        fecha_publicacion: this.firstFormGroup.controls['fecha_publicacion'].value,
        numero_paginas: this.firstFormGroup.controls['numero_paginas'].value,
        editorial: this.firstFormGroup.controls['editorial'].value,
        numero_edicion: this.firstFormGroup.controls['numero_edicion'].value,
        año_edicion: this.firstFormGroup.controls['ano_edicion'].value,
        volumen: this.firstFormGroup.controls['volumen'].value,
        tomo: this.firstFormGroup.controls['tomo'].value,
        titulo_traducido: this.firstFormGroup.controls['titulo_traducido'].value,
        idioma_traducido: this.firstFormGroup.controls['idioma_traducido'].value,
        pais: this.firstFormGroup.controls['pais'].value,
        idioma: this.firstFormGroup.controls['idioma'].value,



      }
      console.log(libro.idioma_traducido);
      this.grupo_autores = this.secondFormGroup.controls['autores'].value;



      let LibroId;
      this.cyadService.postLibro(libro).subscribe({
        next: result => {
          this.buscarLibro(libro);
        },
        error: error => console.log(error)
      });
    }

  }

  buscarLibro(libro: Libro) {
    this.cyadService.findLibro(libro).subscribe({
      next: result2 => {
        console.log("Result was the following " + result2.id);
        //Tercero tomamos las producciones como una lista 
        
          this.addProducciones(result2.id);
        



      },
      error: error => console.log(error)
    })
  }

  onKey(value: EventTarget | null){

    let filterValue: string;
    filterValue = (value as HTMLInputElement).value;
    console.log(filterValue);
    this.filteredAutores = this.listAutores.filter(autor => autor.nombre.concat(autor.primerApellido, autor.segundoApellido).toLowerCase().includes(filterValue.toLowerCase()));
  } 
  

  addProducciones(LibroId: number) {
    for (let i = 0; i < this.autores.length; i++) {
      const item = this.autores.at(i).value;
      let produccion;
      produccion = {

        libro: {
          id: LibroId
        },
        autor: {
          id: item.autor
        },
        orden: {
          id: item.orden
        }
      }

      this.cyadService.postProduccionLibro(produccion).subscribe({
        next: result => {
          let res:ApiResult;
                res = result; 
                if(res.response == true)
                {
                  alert("EXITO AL REGISTRAR LA PRODUCCIÓN")
                  window.location.reload();
                }
                else
                {
                  alert(res.message);
                }
        },
        error: error => alert('Error al resgistrar Libro')
      });
    }
  }

  openDialog(){
    const dialogRef =  this.dialog.open(AutorDetailComponent);
    dialogRef.afterClosed().subscribe(
      val =>{
        if(val === 'save'){
          /**cargando listas */
          this.cyadService.getAutoresEditores().subscribe({
            next:(res)=>{
              this.listAutores = res;
            }

          });
        }
        this.agregarAutor();
      }
    );

  }
}




