import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LibroRegisterComponent } from './libro-register.component';

describe('LibroRegisterComponent', () => {
  let component: LibroRegisterComponent;
  let fixture: ComponentFixture<LibroRegisterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LibroRegisterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LibroRegisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
