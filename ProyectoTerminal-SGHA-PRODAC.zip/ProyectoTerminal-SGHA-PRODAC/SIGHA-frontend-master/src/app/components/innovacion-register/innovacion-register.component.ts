import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TooltipComponent } from '@angular/material/tooltip';
import { Router } from '@angular/router';
import { pairs } from 'rxjs';
import { AutorEditor } from 'src/app/interfaces/autor-editor';
import { Innovacion } from 'src/app/interfaces/innovacion';
import { Orden } from 'src/app/interfaces/orden';
import { CyadService } from 'src/app/service/cyad.service';
import { MatDialog } from '@angular/material/dialog';
import { AutorDetailComponent } from '../autor-detail/autor-detail.component';
import { ApiResult } from 'src/app/interfaces/api-result';

@Component({
  selector: 'app-innovacion-register',
  templateUrl: './innovacion-register.component.html',
  styleUrls: ['./innovacion-register.component.scss']
})
export class InnovacionRegisterComponent implements OnInit {

  firstFormGroup!: FormGroup;
  secondFormGroup!: FormGroup;
  /**listas */
  listAutores !: AutorEditor[];
  listOrden !: Orden[];

  public grupo_autores?: any = [];
  public orden?: Orden;
  autores_select !: any[];
  public filteredAutores?: AutorEditor[];
  constructor(private cyadService: CyadService, private route: Router, private formBuilder: FormBuilder,private dialog: MatDialog) { }

  ngOnInit(): void {
    this.firstFormGroup = this.formBuilder.group({
      nombre: ['', Validators.required],
      fecha_finalizacion: ['', Validators.required],
      descripcion: ['', Validators.required],
      

    });
    this.secondFormGroup = this.formBuilder.group({
      autores: this.formBuilder.array([])
    });


    /**cargando listas */
    this.cyadService.getAutoresEditores().subscribe({
      next: (res) => {
        this.listAutores = res;
        this.filteredAutores = this.listAutores;
      }
    });


    this.cyadService.getOrdenes().subscribe({
      next: (res) => {
        this.listOrden = res;
      }
    });
  }

  /**agregar campos de forma dinamica */
  get autores() {
    return this.secondFormGroup.get('autores') as FormArray;
  }




  agregarAutor() {
    const autoresFormGroup = this.formBuilder.group({
      autor: ['', Validators.required],
      orden: ['', Validators.required]
    });
    this.autores.push(autoresFormGroup);
  }


  removerAutor(indice: number) {
    this.autores.removeAt(indice);
  }

  refresh() {
    this.autores.controls.splice(0, this.autores.length);
  }
  onKey(value: EventTarget | null){

    let filterValue: string;
    filterValue = (value as HTMLInputElement).value;
    console.log(filterValue);
    this.filteredAutores = this.listAutores.filter(autor => autor.nombre.concat(autor.primerApellido, autor.segundoApellido).toLowerCase().includes(filterValue.toLowerCase()));
  } 


  addProduccion() {

    if (this.firstFormGroup.valid && this.secondFormGroup.valid) {
      /* Creamos los objetos que llenamos en el formgroup */
      let innovacion: Innovacion;

      let revistaId: Number;




      innovacion = {
        // obtenemos los datos requeridos de la interface articulo desde los formgroups
        // estos datos se obtienen a partir de su formControlName
        nombre: this.firstFormGroup.controls['nombre'].value,
        fecha_fin: this.firstFormGroup.controls['fecha_finalizacion'].value,
        descripcion: this.firstFormGroup.controls['descripcion'].value



      }
      console.log(innovacion.nombre);
      this.grupo_autores = this.secondFormGroup.controls['autores'].value;



      let LibroId;
      this.cyadService.postInnovacion(innovacion).subscribe({
        next: result => {
          this.buscarInnovacion(innovacion);
        },
        error: error => console.log(error)
      });
    }

  }

  buscarInnovacion(innovacion: Innovacion) {
    this.cyadService.findInnovacion(innovacion).subscribe({
      next: result2 => {
        console.log("Result was the following " + result2.id);
        //Tercero tomamos las producciones como una lista 
        if (this.verifyProducciones(result2.id) == false) {
          alert("Por favor verifique la información introducida");
        }
        else {
          this.addProducciones(result2.id);
        }
      },
      error: error => console.log(error)
    })
  }
  verifyProducciones(innovacionId: number) {
    let flag: boolean;
    flag = true;
    if (innovacionId == null) {
      console.log("Información nula de la producción académica");
      alert("Información nula de la producción académica");
      flag = false;
    }
    if (this.autores.length > 1) {
      for (let i = 0; i < this.autores.length; i++) {
        const item1 = this.autores.at(i).value;
        const item2 = this.autores.at(i++).value;
        console.log(item1.orden + "hola" + item2.orden);
        if (item1.orden == item2.orden) {
          console.log("The orders are repited, please verify");
          alert("The orders of the authors are repited, please verify");
          flag = false;
        }

      }

      for (let u = 0; u < this.autores.length; u++) {
        const item1 = this.autores.at(u).value;
        const item2 = this.autores.at(u++).value;
        if (item1.autor == item2.autor) {
          console.log("The authors are repited, please verify");
          alert("The authors are repited, please verify");
          flag = false;
        }
      }
    }
    return flag;
  }

  addProducciones(InnovacionId: number) {
    if (InnovacionId == null) {
      return;
    }
    for (let i = 0; i < this.autores.length; i++) {
      const item = this.autores.at(i).value;
      let produccion;
      produccion = {
        
       innovacion: {
          id: InnovacionId
        },
        autor: {
          id: item.autor
        },
        orden: {
          id: item.orden
        }
      }

      this.cyadService.postProduccionInnovacion(produccion).subscribe({
        next: result => {
          let res:ApiResult;
                res = result; 
                if(res.response == true)
                {
                  alert("EXITO AL REGISTRAR LA PRODUCCIÓN")
                  window.location.reload();
                }
                else
                {
                  alert(res.message);
                }
        },
        error: error => alert('Error al resgistrar Innovación')
      });
    }
  }
  openDialog(){
    const dialogRef =  this.dialog.open(AutorDetailComponent);
    dialogRef.afterClosed().subscribe(
      val =>{
        if(val === 'save'){
          /**cargando listas */
          this.cyadService.getAutoresEditores().subscribe({
            next:(res)=>{
              this.listAutores = res;
            }

          });
        }
        this.agregarAutor();
      }
    );

  }
}
