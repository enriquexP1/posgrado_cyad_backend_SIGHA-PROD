import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InnovacionRegisterComponent } from './innovacion-register.component';

describe('InnovacionRegisterComponent', () => {
  let component: InnovacionRegisterComponent;
  let fixture: ComponentFixture<InnovacionRegisterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InnovacionRegisterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InnovacionRegisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
