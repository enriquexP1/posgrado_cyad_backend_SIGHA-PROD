import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentoRespaldoDetailComponent } from './documento-respaldo-detail.component';

describe('DocumentoRespaldoDetailComponent', () => {
  let component: DocumentoRespaldoDetailComponent;
  let fixture: ComponentFixture<DocumentoRespaldoDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocumentoRespaldoDetailComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentoRespaldoDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
