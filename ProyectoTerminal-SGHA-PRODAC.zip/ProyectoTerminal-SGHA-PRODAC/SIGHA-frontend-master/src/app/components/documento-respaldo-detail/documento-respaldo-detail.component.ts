import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CyadService } from 'src/app/service/cyad.service';
import { DocumentoRespaldo } from 'src/app/interfaces/documento-respaldo';

@Component({
  selector: 'app-documento-respaldo-detail',
  templateUrl: './documento-respaldo-detail.component.html',
  styleUrls: ['./documento-respaldo-detail.component.scss']
})
export class DocumentoRespaldoDetailComponent implements OnInit {

  
  areaForm!: FormGroup;
  title: string = "Nuevo tipo de documento de respaldo";
  actionBtn: string = "Guardar";

  

  constructor(
    private cyadService: CyadService,
    private formBuilder: FormBuilder,
    public dialogRef: MatDialogRef<DocumentoRespaldoDetailComponent>,
    @Inject(MAT_DIALOG_DATA) public editData: DocumentoRespaldo,
  ) { }

  ngOnInit(): void {
    /*Agregando validaciones a los input*/
    this.areaForm = this.formBuilder.group({
      documentoRespaldo: ['', Validators.required],
    });

  }

  submitDocumentoRespaldo() {
    if (this.actionBtn == "Guardar") {
      this.addDocumentoRespaldo();
    } else if (this.actionBtn == "Actualizar") {
      
    }
  }
  onNoClick(): void {
    this.dialogRef.close();
  }

  addDocumentoRespaldo() {
    if (!this.editData) {
      if (this.areaForm.valid) {

        

        /**estructura */
        let documentoRespaldo: DocumentoRespaldo;

        documentoRespaldo = {
          documento: this.areaForm.controls['documentoRespaldo'].value,
        }


        console.log(documentoRespaldo);
        /**llamada al servicio */
        this.cyadService.postDocumentoRespaldo(documentoRespaldo)
          .subscribe({
            next: (res) => {
              console.log(res);
              alert("Tipo de documento de respaldo add successfully");
              this.areaForm.reset();
              this.dialogRef.close('save');
            },
            error: (err) => {
              alert("Error while adding the tipo de documento de respaldo " + err);
            }
          })
      }
    }
    
  }

}
