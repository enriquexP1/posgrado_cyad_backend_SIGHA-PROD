import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ResenaRegisterComponent } from './resena-register.component';

describe('ResenaRegisterComponent', () => {
  let component: ResenaRegisterComponent;
  let fixture: ComponentFixture<ResenaRegisterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ResenaRegisterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ResenaRegisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
