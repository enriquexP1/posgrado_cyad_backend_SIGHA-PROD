import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InstitucionTableComponent } from './institucion-table.component';

describe('InstitucionTableComponent', () => {
  let component: InstitucionTableComponent;
  let fixture: ComponentFixture<InstitucionTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InstitucionTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InstitucionTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
