import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CuentaProduccionesComponent } from './cuenta-producciones.component';

describe('CuentaProduccionesComponent', () => {
  let component: CuentaProduccionesComponent;
  let fixture: ComponentFixture<CuentaProduccionesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CuentaProduccionesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CuentaProduccionesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
