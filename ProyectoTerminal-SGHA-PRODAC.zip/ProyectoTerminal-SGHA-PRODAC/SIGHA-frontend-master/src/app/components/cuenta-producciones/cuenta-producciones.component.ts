import { Component, OnInit } from '@angular/core';
import {Chart, registerables} from "chart.js";
import { CyadService } from 'src/app/service/cyad.service';
import { CuentaProduccionDatamart } from 'src/app/interfaces/cuenta-produccion-datamart';
@Component({
  selector: 'app-cuenta-producciones',
  templateUrl: './cuenta-producciones.component.html',
  styleUrls: ['./cuenta-producciones.component.scss']
})
export class CuentaProduccionesComponent implements OnInit {

  public chart?: Chart;
  public frecuenciaProducciones: Map<String, Number>= new Map();
  
  constructor(private service: CyadService) { 
    Chart.register(...registerables);
  }
  ngOnInit(): void {
    this.loadData();
  }

  loadData(){
    this.service.getCuentasProducciones().subscribe({
      next: result =>{
        let fixedResult: CuentaProduccionDatamart[] = result;
        this.createChart(fixedResult);
      },
      error: error => console.error(error)
    })
  }

  createChart(frecuencia: CuentaProduccionDatamart[]){
    if(frecuencia == null)
    {
      alert('¡No existe información para mostrar datos!');
    }
    var nombres: String[] = [];
    var cuentas: Number[] = [];
    frecuencia.forEach(element => {
      nombres.push(element.tipoProduccion);
      cuentas.push(element.cuenta);
    })
    if(this.chart){
      this.chart.destroy();
    }
    this.chart = new Chart("ChartProducciones", {
      type: 'bar',
      data: {
        //labels: ['Articulo','Conferencia','Desarrollo tecnólogico', 'Documentos de trabajo', 'Innovación','Libro','Memoria', 'Presentación', 'Reporte','Reseña'],
        labels: nombres,
        datasets:[{
          label: "Cuentas de todas las producciones",
          data: cuentas,
          backgroundColor: [
            'rgba(255, 99, 132, 0.2)',
            'rgba(255, 159, 64, 0.2)',
            'rgba(255, 205, 86, 0.2)',
            'rgba(75, 192, 192, 0.2)',
            'rgba(54, 162, 235, 0.2)',
            'rgba(153, 102, 255, 0.2)',
            'rgba(201, 203, 207, 0.2)',
            'rgba(57, 13, 56, 0.2)',
            'rgba(210, 300, 90, 0.2)',
            'rgba(125, 192, 76, 0.2)'
          
          ],
          borderColor: [
            'rgb(255, 99, 132)',
            'rgb(255, 159, 64)',
            'rgb(255, 205, 86)',
            'rgb(75, 192, 192)',
            'rgb(54, 162, 235)',
            'rgb(153, 102, 255)',
            'rgb(201, 203, 207)',
            'rgb(57, 13, 56)',
            'rgb(210, 300, 90)',
            'rgb(125, 192, 76)'
          ],
          borderWidth: 1
        }]
      },
      options: {
        aspectRatio: 0.5,
        maintainAspectRatio: false,
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });
  }


}
