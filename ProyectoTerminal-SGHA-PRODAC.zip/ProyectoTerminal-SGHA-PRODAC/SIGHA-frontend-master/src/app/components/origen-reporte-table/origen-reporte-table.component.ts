import { Component, OnInit,ViewChild  } from '@angular/core';

import { CyadService } from 'src/app/service/cyad.service';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { MatDialog } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { OrigenReporteDetailComponent } from '../origen-reporte-detail/origen-reporte-detail.component';

@Component({
  selector: 'app-origen-reporte-table',
  templateUrl: './origen-reporte-table.component.html',
  styleUrls: ['./origen-reporte-table.component.scss']
})
export class OrigenReporteTableComponent implements OnInit {

  title: string = "Tipos de origenes de reportes";
  displayedColumns: String[] = ['id', 'origen_reporte'];
  data: any[] = [];
  dataSource = new MatTableDataSource<any>(this.data);
  resultsLength:number = 0;


  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(private cyadService: CyadService, private dialog: MatDialog) { }

  ngOnInit(): void {
    this.getAllOrigenesReportes();
  }

  getAllOrigenesReportes(){
    this.cyadService.getOrigenesReporte().subscribe({
      next:(res)=>{
        this.dataSource = new MatTableDataSource(res);
        console.log(res);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      },
      error:(err)=>{
        console.error(err);
      }
    });
  }

  applyFilter(event : Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  openDialog(){
    const dialogRef =  this.dialog.open(OrigenReporteDetailComponent);

    dialogRef.afterClosed().subscribe(
      val =>{
        if(val === 'save'){
          this.getAllOrigenesReportes();
        }
      }
    );
  }

}
