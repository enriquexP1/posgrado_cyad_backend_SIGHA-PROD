import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OrigenReporteTableComponent } from './origen-reporte-table.component';

describe('OrigenReporteTableComponent', () => {
  let component: OrigenReporteTableComponent;
  let fixture: ComponentFixture<OrigenReporteTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OrigenReporteTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OrigenReporteTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
