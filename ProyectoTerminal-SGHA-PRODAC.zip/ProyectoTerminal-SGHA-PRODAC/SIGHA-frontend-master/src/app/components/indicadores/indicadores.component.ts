import { Component, OnInit } from '@angular/core';
import {Chart, registerables} from "chart.js";
import { CyadService } from 'src/app/service/cyad.service';
import {FrecuenciaProduccionDatamart} from "../../interfaces/frecuencia-produccion-datamart";


@Component({
  selector: 'app-indicadores',
  templateUrl: './indicadores.component.html',
  styleUrls: ['./indicadores.component.scss']
})
export class IndicadoresComponent implements OnInit {

  public chart?: Chart;
  public frecuenciasAnos: Map<Number, Number> = new Map();
  private filter: number = 1998;
  
  private fechasPorAnnio: FrecuenciaProduccionDatamart[] = []; 
  private monthFilter: number[] = new Array(0,0,0,0,0,0,0,0,0,0,0,0);

  constructor(private service:CyadService) {
    Chart.register(...registerables);
   }

  ngOnInit(): void {
    //this.loadData();
    this.loadYears();
  }

  onChange(newValue: number){
    if(newValue == 0){
      this.loadYears();
    }else{
      this.loadData(newValue)
    }
  }
  loadData(valueFilter: number){
    this.service.getFrecuenciaProduccionesANO(valueFilter).subscribe({
      next: result =>{
        this.fechasPorAnnio = result;
        this.monthFilter = this.monthCount(this.fechasPorAnnio);
        this.createChart(this.monthFilter, valueFilter.toString());
      }
    })
  }
  loadYears(){
    this.service.getFrecuenciaProduccionesAnos().subscribe({
      next: result =>{
        this.frecuenciasAnos = result;
        this.yearData(this.frecuenciasAnos);
        console.log(this.frecuenciasAnos);

      }
    })
  }

  yearData(frecuencia: Map<Number,Number>){
    if(this.chart){
      this.chart.destroy();
    }
    let llaves: String[] = Object.keys(frecuencia);
    let values: Number[];
  
    //console.log("Las llaves de frecuencia son: "+Object.keys(frecuencia))
    //console.log("Las entries de frecuencia son: " +Object.values(frecuencia))
    this.chart = new Chart("ChartIndicadores", {
      type: 'line',
      data: {
        datasets:[
          {
            label: "Todos los años",
            data: Object.entries(frecuencia),
            backgroundColor: 'red'
          }
        ]
      },
      options:{
        aspectRatio: 2,
        maintainAspectRatio: true,
        scales:{
          y: {
            beginAtZero: true
          }
        }
      }
    })
  }
  pinYear(){
    console.log("HOLA");
  }
  monthCount(frecuencias: FrecuenciaProduccionDatamart[]):number[] {
    let meses: number[] = new Array(0,0,0,0,0,0,0,0,0,0,0,0);
    frecuencias.forEach(test => {
       //console.log(test);
       let thisDate: Date = new Date(test.fecha);
       meses[thisDate.getMonth()] += test.cuenta;
    });
    return meses;
  }
  createChart(meses: number[], label: string){
    if(this.chart){
      this.chart.destroy();
    }
    this.chart = new Chart("ChartIndicadores", {
      type: 'line',
      data: { // valores en x
        labels: [
          'Enero',
          'Febrero',
          'Marzo',
          'Abril',
          'Mayo',
          'Junio',
          'Julio',
          'Agosto',
          'Septiembre',
          'Octubre',
          'Noviembre',
          'Diciembre'
        ],
        datasets: [
          {
            label: label,
            /*data: [meses[0], meses[1], meses[2], meses[3], meses[4],
            meses[5], meses[6], meses[7], meses[8], meses[9],
            meses[10], meses[11]]*/
            data: meses,
            backgroundColor: 'red'
          }
        ]
       },
       options: {
        aspectRatio: 2,
        maintainAspectRatio: true
      }
    });
  }
}
