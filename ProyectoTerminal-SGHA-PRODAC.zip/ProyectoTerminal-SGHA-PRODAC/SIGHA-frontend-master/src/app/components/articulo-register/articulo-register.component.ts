import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AutorEditor } from 'src/app/interfaces/autor-editor';
import { Orden } from 'src/app/interfaces/orden';
import { CyadService } from 'src/app/service/cyad.service';

import { Articulo } from 'src/app/interfaces/articulo';
import { Revista } from 'src/app/interfaces/revista';
import { __await } from 'tslib';
import { ApiResult } from 'src/app/interfaces/api-result';

import { MatDialog } from '@angular/material/dialog';
import { AutorDetailComponent } from '../autor-detail/autor-detail.component';

@Component({
  selector: 'app-articulo-register',
  templateUrl: './articulo-register.component.html',
  styleUrls: ['./articulo-register.component.scss']
})
export class ArticuloRegisterComponent implements OnInit {

  firstFormGroup!: FormGroup;
  secondFormGroup!: FormGroup;
  thirdFormGroup !: FormGroup;
  /**listas */
 
  listAutores !: AutorEditor[];
  listOrden !: Orden[];
  listRevistas !: Revista[];
  public filteredAutores?: AutorEditor[];
  /**variables de documento */
  loading: boolean = false; // bandera
  file !: File; // variable para almacenar

  /**/
  public grupo_autores?: any = [];
  public orden?: Orden;
  autores_select !: any[];

  constructor(private cyadService: CyadService, private route: Router, private formBuilder: FormBuilder, private dialog: MatDialog) { }

  ngOnInit(): void {
    this.firstFormGroup = this.formBuilder.group({
      titulo: ['', Validators.required],
      doi:['', Validators.required],
      pagina_inicio:['', Validators.required],
      pagina_final:['', Validators.required],
      pais:['', Validators.required],
      idioma:['', Validators.required],
      fecha_publicacion: ['', Validators.required],
      fecha_aceptacion: ['', Validators.required],
      revista: ['', Validators.required]
    });
    this.secondFormGroup = this.formBuilder.group({
      autores: this.formBuilder.array([])
    });
   
    /**cargando listas */
    this.cyadService.getAutoresEditores().subscribe({
      next:(res)=>{
        this.listAutores = res;
        this.filteredAutores = this.listAutores;
      }
    });

    this.cyadService.getRevistas().subscribe({
      next: res =>{
        this.listRevistas = res;
      }
    });
    this.cyadService.getOrdenes().subscribe({
      next:(res)=>{
        this.listOrden = res;
      }
    });
  }

  /**agregar campos de forma dinamica */
  get autores(){
    return this.secondFormGroup.get('autores') as FormArray;
  }

  get revistas(){
    return this.thirdFormGroup.get('revistas') as FormArray;
  }

  agregarRevista(){
    const revistasFormGroup = this.formBuilder.group({
      revista: ['', Validators.required],
    });
    this.revistas.push(revistasFormGroup);
  }
  agregarAutor() {
    const autoresFormGroup = this.formBuilder.group({
      autor: ['', Validators.required],
      orden: ['', Validators.required]
    });
    this.autores.push(autoresFormGroup);
  }

  removerRevista(indice: number){
    this.revistas.removeAt(indice);
  }
  removerAutor(indice: number) {
    this.autores.removeAt(indice);
  }

  refresh() {
    this.autores.controls.splice(0, this.autores.length);
  }

  
 /* onChange( event : any ) {
    this.file = event.target.files[0];
    this.loading = true;
    console.log('se cargo un archivo '+ this.file);
  }*/

  onKey(value: EventTarget | null){

    let filterValue: string;
    filterValue = (value as HTMLInputElement).value;
    console.log(filterValue);
    this.filteredAutores = this.listAutores.filter(autor => autor.nombre.concat(autor.primerApellido, autor.segundoApellido).toLowerCase().includes(filterValue.toLowerCase()));
  } 
  


  addProduccion(){
    console.log("First:" + this.firstFormGroup.valid + "\nSecond: " + this.secondFormGroup.valid );
    if (this.firstFormGroup.valid && this.secondFormGroup.valid){
      /* Creamos los objetos que llenamos en el formgroup */
      let articulo: Articulo;
      
      let revistaId: Number;
      let revista: Revista = {
        id: this.firstFormGroup.controls['revista'].value
      }
 

     
      
    
      articulo = {
        // obtenemos los datos requeridos de la interface articulo desde los formgroups
        // estos datos se obtienen a partir de su formControlName
        doi: this.firstFormGroup.controls['doi'].value, 
        titulo: this.firstFormGroup.controls['titulo'].value,
        fecha_publicacion: this.firstFormGroup.controls['fecha_publicacion'].value,
        fecha_aceptacion: this.firstFormGroup.controls['fecha_aceptacion'].value,
        pagina_inicio: this.firstFormGroup.controls['pagina_inicio'].value,
        pagina_fin: this.firstFormGroup.controls['pagina_final'].value,
        revista: revista,
        pais: this.firstFormGroup.controls['pais'].value,
        idioma: this.firstFormGroup.controls['idioma'].value
      }

      console.log("Articulo agregado:  " + articulo.doi + " " + articulo.titulo);
      this.grupo_autores = this.secondFormGroup.controls['autores'].value;

    

    let articuloId;
     this.cyadService.postArticulo(articulo).subscribe({
        next: result => {
            this.buscarArticulo(articulo);
        },
        error: error => console.log(error)
      });
      
    
      }
     
  }

    buscarArticulo(articulo: Articulo){
      this.cyadService.findArticulo(articulo).subscribe({
        next: result2 => {
          console.log("Result was the following " + result2);

         
            this.addProducciones(result2.id);
          
        },
        error: error => console.log(error)
      })
    }
    
   

    addProducciones(articuloId: number){
      if(articuloId == null){
        return;
      }
      for (let i = 0; i < this.autores.length; i++) {
          const item = this.autores.at(i).value;
          let produccion;

          produccion = {
            articulo: {
              id: articuloId
            },
            autor: {
              id: item.autor
            },
            orden: {
              id: item.orden
            }

            
          }
          console.log(produccion);
          
          this.cyadService.postProduccionArticulo(produccion).subscribe({
            next: result => {
                let res:ApiResult;
                res = result; 
                if(res.response == true)
                {
                  alert("EXITO AL REGISTRAR LA PRODUCCIÓN")
                  window.location.reload();
                }
                else
                {
                  alert(res.message);
                }
                //console.log(JSON.stringify(result));
                //JSON.stringify(result)
                //alert(JSON.stringify(result));
              
            },
            error: error => alert('Error al resgistrar Articulo')
          });
      }
    }
    openDialog(){
      const dialogRef =  this.dialog.open(AutorDetailComponent);
      dialogRef.afterClosed().subscribe(
        val =>{
          if(val === 'save'){
            /**cargando listas */
            this.cyadService.getAutoresEditores().subscribe({
              next:(res)=>{
                this.listAutores = res;
              }

            });
          }
          this.agregarAutor();
        }
      );

    }
  }

