import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { InstitucionProduccionAcademica } from 'src/app/interfaces/institucion-produccion-academica';
import { CyadService } from 'src/app/service/cyad.service';

@Component({
  selector: 'app-institucion-detail',
  templateUrl: './institucion-detail.component.html',
  styleUrls: ['./institucion-detail.component.scss']
})
export class InstitucionDetailComponent implements OnInit {

  areaForm!: FormGroup;
  title: string = "Nuevo autor";
  actionBtn: string = "Guardar";

  

  constructor(
    private cyadService: CyadService,
    private formBuilder: FormBuilder,
    public dialogRef: MatDialogRef<InstitucionDetailComponent>,
    @Inject(MAT_DIALOG_DATA) public editData: InstitucionProduccionAcademica,
  ) { }

  ngOnInit(): void {
    /*Agregando validaciones a los input*/
    this.areaForm = this.formBuilder.group({
      nombre: ['', Validators.required],
      publica_privada: ['', Validators.required],
      tipo_institucion: ['', Validators.required]
     
    });

  }

  submitInstitucion() {
    if (this.actionBtn == "Guardar") {
      this.addInstitucion();
    } 
  }
  onNoClick(): void {
    this.dialogRef.close();
  }

  addInstitucion() {
    if (!this.editData) {
      if (this.areaForm.valid) {

        // Recuperando
        let publica_privada: boolean, autorEditor: boolean
        if (this.areaForm.controls['publica_privada'].value == "Publica") publica_privada = false;
        else { publica_privada = true };

        /**estructura */
        let institucion: InstitucionProduccionAcademica;

        institucion = {
          nombre: this.areaForm.controls['nombre'].value,
          publica_privada: publica_privada,
          tipo_institucion: this.areaForm.controls['tipo_institucion'].value
        }


        console.log(institucion);
        /**llamada al servicio */
        this.cyadService.postInstitucionProduccionAcademica(institucion)
          .subscribe({
            next: (res) => {
              console.log(res);
              alert("Institution add successfully");
              this.areaForm.reset();
              this.dialogRef.close('save');
            },
            error: (err) => {
              alert("Error while adding the Institution " + err);
            }
          })
      }
    }
    
  }



}
