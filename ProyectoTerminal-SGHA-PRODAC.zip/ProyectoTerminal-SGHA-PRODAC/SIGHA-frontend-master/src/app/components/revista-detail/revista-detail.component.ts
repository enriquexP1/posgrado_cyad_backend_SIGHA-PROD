import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CyadService } from 'src/app/service/cyad.service';

import { Revista } from 'src/app/interfaces/revista';

@Component({
  selector: 'app-revista-detail',
  templateUrl: './revista-detail.component.html',
  styleUrls: ['./revista-detail.component.scss']
})
export class RevistaDetailComponent implements OnInit {

  areaForm!: FormGroup;
  title: string = "Nuevo autor";
  actionBtn: string = "Guardar";

  

  constructor(
    private cyadService: CyadService,
    private formBuilder: FormBuilder,
    public dialogRef: MatDialogRef<RevistaDetailComponent>,
    @Inject(MAT_DIALOG_DATA) public editData: Revista,
  ) { }

  ngOnInit(): void {
    /*Agregando validaciones a los input*/
    this.areaForm = this.formBuilder.group({
      nombre: ['', Validators.required],
      numero: ['', Validators.required],
      issn: ['', Validators.required]
    });

    /*Al iniciar el cuadro de dialogo
    si se tarta de una edición*/
    if (this.editData) {
      this.title = "Actualizar autor";
      this.actionBtn = "Actualizar";
      this.areaForm.controls['nombre'].setValue(this.editData.nombre);
      this.areaForm.controls['numero'].setValue(this.editData.numero);
      this.areaForm.controls['issn'].setValue(this.editData.issn);
    }

    /*El id es un campo gestionado por el servicio*/
    //this.areaForm.controls['id'].disable();



  }

  submitRevista() {
    if (this.actionBtn == "Guardar") {
      this.addRevista();
    } else if (this.actionBtn == "Actualizar") {
      
    }
  }
  onNoClick(): void {
    this.dialogRef.close();
  }

  addRevista() {
    if (!this.editData) {
      if (this.areaForm.valid) {

        

        /**estructura */
        let revista: Revista;

        revista = {
          nombre: this.areaForm.controls['nombre'].value,
          numero: this.areaForm.controls['numero'].value,
          issn: this.areaForm.controls['issn'].value,
        }


        console.log(revista);
        /**llamada al servicio */
        this.cyadService.postRevista(revista)
          .subscribe({
            next: (res) => {
              console.log(res);
              alert("Revista add successfully");
              this.areaForm.reset();
              this.dialogRef.close('save');
              window.location.reload();
            },
            error: (err) => {
              alert("Error while adding the autor " + err);
            }
          })
      }
    }
    else {
      this.areaForm.controls['id'].enable();//habilita input
    }
  }

}
