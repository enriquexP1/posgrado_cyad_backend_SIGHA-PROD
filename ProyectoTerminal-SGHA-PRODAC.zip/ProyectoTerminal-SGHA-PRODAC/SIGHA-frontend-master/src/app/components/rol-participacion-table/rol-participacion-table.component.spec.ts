import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RolParticipacionTableComponent } from './rol-participacion-table.component';

describe('RolParticipacionTableComponent', () => {
  let component: RolParticipacionTableComponent;
  let fixture: ComponentFixture<RolParticipacionTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RolParticipacionTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RolParticipacionTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
