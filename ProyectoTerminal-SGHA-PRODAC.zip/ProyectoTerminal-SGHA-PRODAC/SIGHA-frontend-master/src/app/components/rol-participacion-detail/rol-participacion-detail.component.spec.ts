import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RolParticipacionDetailComponent } from './rol-participacion-detail.component';

describe('RolParticipacionDetailComponent', () => {
  let component: RolParticipacionDetailComponent;
  let fixture: ComponentFixture<RolParticipacionDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RolParticipacionDetailComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RolParticipacionDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
