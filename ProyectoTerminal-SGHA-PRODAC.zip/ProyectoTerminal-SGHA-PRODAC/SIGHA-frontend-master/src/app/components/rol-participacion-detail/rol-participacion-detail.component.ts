import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RolParticipacion } from 'src/app/interfaces/rol-participacion';
import { CyadService } from 'src/app/service/cyad.service';

@Component({
  selector: 'app-rol-participacion-detail',
  templateUrl: './rol-participacion-detail.component.html',
  styleUrls: ['./rol-participacion-detail.component.scss']
})
export class RolParticipacionDetailComponent implements OnInit {

  areaForm!: FormGroup;
  title: string = "Nuevo autor";
  actionBtn: string = "Guardar";

  

  constructor(
    private cyadService: CyadService,
    private formBuilder: FormBuilder,
    public dialogRef: MatDialogRef<RolParticipacionDetailComponent>,
    @Inject(MAT_DIALOG_DATA) public editData: RolParticipacion,
  ) { }

  ngOnInit(): void {
    /*Agregando validaciones a los input*/
    this.areaForm = this.formBuilder.group({
      rolParticipacion: ['', Validators.required],
    });

    /*Al iniciar el cuadro de dialogo
    si se tarta de una edición*/
    if (this.editData) {
      this.title = "Actualizar autor";
      this.actionBtn = "Actualizar";
      this.areaForm.controls['rolParticipacion'].setValue(this.editData.rol);
    }

    /*El id es un campo gestionado por el servicio*/
    //this.areaForm.controls['id'].disable();



  }

  submitRolParticipacion() {
    if (this.actionBtn == "Guardar") {
      this.addRevista();
    } else if (this.actionBtn == "Actualizar") {
      
    }
  }
  onNoClick(): void {
    this.dialogRef.close();
  }

  addRevista() {
    if (!this.editData) {
      if (this.areaForm.valid) {

        

        /**estructura */
        let rolParticipacions: RolParticipacion;

        rolParticipacions = {
          rol: this.areaForm.controls['rolParticipacion'].value
        }


        console.log(rolParticipacions);
        /**llamada al servicio */
        this.cyadService.postRolParticipacion(rolParticipacions)
          .subscribe({
            next: (res) => {
              console.log(res);
              alert("Rol de Participacion add successfully");
              this.areaForm.reset();
              this.dialogRef.close('save');
              this.ngOnInit();
            },
            error: (err) => {
              alert("Error while adding the rol de participacion " + err);
            }
          })
      }
    }
    else {
      //this.areaForm.controls['id'].enable();//habilita input
    }
  }

}
