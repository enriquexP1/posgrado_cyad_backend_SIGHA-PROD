import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TipoDesarrolloTableComponent } from './tipo-desarrollo-table.component';

describe('TipoDesarrolloTableComponent', () => {
  let component: TipoDesarrolloTableComponent;
  let fixture: ComponentFixture<TipoDesarrolloTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TipoDesarrolloTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TipoDesarrolloTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
