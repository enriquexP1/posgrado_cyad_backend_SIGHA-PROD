import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentoRespaldoTableComponent } from './documento-respaldo-table.component';

describe('DocumentoRespaldoTableComponent', () => {
  let component: DocumentoRespaldoTableComponent;
  let fixture: ComponentFixture<DocumentoRespaldoTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocumentoRespaldoTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentoRespaldoTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
