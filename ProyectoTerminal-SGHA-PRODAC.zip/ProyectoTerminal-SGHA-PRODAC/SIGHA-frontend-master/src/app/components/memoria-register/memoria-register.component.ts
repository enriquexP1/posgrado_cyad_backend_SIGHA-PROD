import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TooltipComponent } from '@angular/material/tooltip';
import { Router } from '@angular/router';
import { CyadService } from 'src/app/service/cyad.service';
import { pairs } from 'rxjs';
import { AutorEditor } from 'src/app/interfaces/autor-editor';
import { Orden } from 'src/app/interfaces/orden';
import { Memoria } from 'src/app/interfaces/memoria';
import { MatDialog } from '@angular/material/dialog';
import { AutorDetailComponent } from '../autor-detail/autor-detail.component';
import { ApiResult } from 'src/app/interfaces/api-result';

@Component({
  selector: 'app-memoria-register',
  templateUrl: './memoria-register.component.html',
  styleUrls: ['./memoria-register.component.scss']
})
export class MemoriaRegisterComponent implements OnInit {

  firstFormGroup!: FormGroup;
  secondFormGroup!: FormGroup;
  /**listas */
  listAutores !: AutorEditor[];
  listOrden !: Orden[];


  public grupo_autores?: any = [];
  autores_select !: any[];
  public filteredAutores?: AutorEditor[];
  constructor(private cyadService: CyadService, private route: Router, private formBuilder: FormBuilder,private dialog: MatDialog) { }

  ngOnInit(): void {
    this.firstFormGroup = this.formBuilder.group({
      titulo: ['', Validators.required],
      titulo_publicacion: ['', Validators.required],
      nombre: ['', Validators.required],
      primer_apellido: ['', Validators.required],
      segundo_apellido: ['', Validators.required],
      pagina_inicio: ['', Validators.required],
      pagina_final: ['', Validators.required],
      fecha_publicacion: ['', Validators.required],
      pais: ['', Validators.required]


    });
    this.secondFormGroup = this.formBuilder.group({
      autores: this.formBuilder.array([])
    });


    /**cargando listas */
    /*Lista de autores editores */
    this.cyadService.getAutoresEditores().subscribe({
      next: (res) => {
        this.listAutores = res;
        this.filteredAutores = this.listAutores;
      }
    });
    this.cyadService.getOrdenes().subscribe({
      next: (res) => {
        this.listOrden = res;
      }
    });



  }

  /**agregar campos de forma dinamica */
  get autores() {
    return this.secondFormGroup.get('autores') as FormArray;
  }




  agregarAutor() {
    const autoresFormGroup = this.formBuilder.group({
      autor: ['', Validators.required],
      orden: ['', Validators.required]
    });
    this.autores.push(autoresFormGroup);
  }


  removerAutor(indice: number) {
    this.autores.removeAt(indice);
  }

  refresh() {
    this.autores.controls.splice(0, this.autores.length);
  }

  onKey(value: EventTarget | null){

    let filterValue: string;
    filterValue = (value as HTMLInputElement).value;
    console.log(filterValue);
    this.filteredAutores = this.listAutores.filter(autor => autor.nombre.concat(autor.primerApellido, autor.segundoApellido).toLowerCase().includes(filterValue.toLowerCase()));
  } 

  addProduccion() {

    if (this.firstFormGroup.valid && this.secondFormGroup.valid) {
      /* Creamos los objetos que llenamos en el formgroup */
      let memoria: Memoria;



      memoria = {
        // obtenemos los datos requeridos de la interface articulo desde los formgroups
        // estos datos se obtienen a partir de su formControlName
        titulo: this.firstFormGroup.controls['titulo'].value,
        titulo_publicacion: this.firstFormGroup.controls['titulo_publicacion'].value,
        nombre: this.firstFormGroup.controls['nombre'].value,
        primer_apellido: this.firstFormGroup.controls['primer_apellido'].value,
        segundo_apellido: this.firstFormGroup.controls['segundo_apellido'].value,
        pagina_inicio: this.firstFormGroup.controls['pagina_inicio'].value,
        pagina_fin: this.firstFormGroup.controls['pagina_final'].value,
        fecha_publicacion: this.firstFormGroup.controls['fecha_publicacion'].value,
        pais: this.firstFormGroup.controls['pais'].value
      }
      console.log(memoria.nombre + memoria.primer_apellido);
      this.grupo_autores = this.secondFormGroup.controls['autores'].value;



      this.cyadService.postMemoria(memoria).subscribe({
        next: result => {
          this.buscarMemoria(memoria);
        },
        error: error => console.log(error)
      });
    }

  }

  buscarMemoria(memoria: Memoria) {
    this.cyadService.findMemoria(memoria).subscribe({
      next: result2 => {
        console.log("Result was the following " + result2.id);
       
          this.addProducciones(result2.id);
        
      },
      error: error => console.log(error)
    })
  }

 

  addProducciones(MemoriaId: number) {
    if (MemoriaId == null) {
      return;
    }
    for (let i = 0; i < this.autores.length; i++) {
      const item = this.autores.at(i).value;
      let produccion;
      produccion = {

        memoria: {
          id: MemoriaId
        },
        autorEditor: {
          id: item.autor
        },
        orden: {
          id: item.orden
        }

      }

      this.cyadService.postProduccionMemoria(produccion).subscribe({
        next: result => {
          let res:ApiResult;
          res = result; 
          if(res.response == true)
          {
            alert("EXITO AL REGISTRAR LA PRODUCCIÓN")
            window.location.reload();
          }
          else
          {
            alert(res.message);
          }
        },
        error: error =>
          alert('Error al resgistrar Memoria')
      });
    }
  }
  openDialog(){
    const dialogRef =  this.dialog.open(AutorDetailComponent);
    dialogRef.afterClosed().subscribe(
      val =>{
        if(val === 'save'){
          /**cargando listas */
          this.cyadService.getAutoresEditores().subscribe({
            next:(res)=>{
              this.listAutores = res;
            }

          });
        }
        this.agregarAutor();
      }
    );

  }

}
