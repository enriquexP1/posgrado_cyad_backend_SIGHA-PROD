import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MemoriaRegisterComponent } from './memoria-register.component';

describe('MemoriaRegisterComponent', () => {
  let component: MemoriaRegisterComponent;
  let fixture: ComponentFixture<MemoriaRegisterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MemoriaRegisterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MemoriaRegisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
