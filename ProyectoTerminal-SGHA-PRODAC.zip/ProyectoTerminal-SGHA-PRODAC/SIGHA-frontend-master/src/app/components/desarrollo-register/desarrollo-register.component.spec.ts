import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DesarrolloRegisterComponent } from './desarrollo-register.component';

describe('DesarrolloRegisterComponent', () => {
  let component: DesarrolloRegisterComponent;
  let fixture: ComponentFixture<DesarrolloRegisterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DesarrolloRegisterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DesarrolloRegisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
