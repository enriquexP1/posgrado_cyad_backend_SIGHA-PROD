import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TooltipComponent } from '@angular/material/tooltip';
import { Router } from '@angular/router';
import { CyadService } from 'src/app/service/cyad.service';
import { pairs } from 'rxjs';
import { AutorEditor } from 'src/app/interfaces/autor-editor';
import { Orden } from 'src/app/interfaces/orden';
import { Desarrollo } from 'src/app/interfaces/desarrollo';
import { DocumentoRespaldo } from 'src/app/interfaces/documento-respaldo';
import { RolParticipacion } from 'src/app/interfaces/rol-participacion';
import { TipoDesarrollo } from 'src/app/interfaces/tipo-desarrollo';
import { MatDialog } from '@angular/material/dialog';
import { AutorDetailComponent } from '../autor-detail/autor-detail.component';
import { ApiResult } from 'src/app/interfaces/api-result';
@Component({
  selector: 'app-desarrollo-register',
  templateUrl: './desarrollo-register.component.html',
  styleUrls: ['./desarrollo-register.component.scss']
})
export class DesarrolloRegisterComponent implements OnInit {

  firstFormGroup!: FormGroup;
  secondFormGroup!: FormGroup;
  /**listas */
  listAutores !: AutorEditor[];
  listOrden !: Orden[];
  listRolesParticipacion !: RolParticipacion[];
  listTiposDesarrollo !: TipoDesarrollo[];
  listDocumentosRespaldo !: DocumentoRespaldo[];

  public grupo_autores?: any = [];
  autores_select !: any[];
  public filteredAutores?: AutorEditor[];

  constructor(private cyadService: CyadService, private route: Router, private formBuilder: FormBuilder,private dialog: MatDialog) { }

  ngOnInit(): void {
    this.firstFormGroup = this.formBuilder.group({
      nombre: ['', Validators.required],
      objetivos: ['', Validators.required],
      resumen: ['', Validators.required],
      fecha_entrega: ['', Validators.required],
      rol_participacion: ['', Validators.required],
      tipo_desarrollo: ['', Validators.required],
      documento_respaldo: ['', Validators.required]
    
    });
    this.secondFormGroup = this.formBuilder.group({
      autores: this.formBuilder.array([])
    });


    /**cargando listas */
    /*Lista de autores editores */
    this.cyadService.getAutoresEditores().subscribe({
      next: (res) => {
        this.listAutores = res;
        this.filteredAutores = this.listAutores;
      }
    });
    /*Lista de roles de participación */
    this.cyadService.getRolDeParticipacion().subscribe({
      next: (res1) => {
        
        this.listRolesParticipacion = res1;
        console.log(this.listRolesParticipacion);
      }
    });
    /*Lista de roles de tipos de desarrollo tecnólogico */
    this.cyadService.getTipoDesarrollo().subscribe({
      next: (res2) => {
        this.listTiposDesarrollo = res2;
      }
    });
    /*Lista de tipos de documentos de respaldo */
    this.cyadService.getDocumentosRespaldo().subscribe({
      next: (res3) => {
        this.listDocumentosRespaldo = res3;
      }
    });
    this.cyadService.getOrdenes().subscribe({
      next:(res)=>{
        this.listOrden = res;
      }
    });



  }

  /**agregar campos de forma dinamica */
  get autores() {
    return this.secondFormGroup.get('autores') as FormArray;
  }
   get rolesParticipacion()
   {
    return this.firstFormGroup.get('rolesParticipacion') as FormArray;
   }



  agregarAutor() {
    const autoresFormGroup = this.formBuilder.group({
      autor: ['', Validators.required],
      orden: ['', Validators.required]
    });
    this.autores.push(autoresFormGroup);
  }


  removerAutor(indice: number) {
    this.autores.removeAt(indice);
  }

  refresh() {
    this.autores.controls.splice(0, this.autores.length);
  }

  onKey(value: EventTarget | null){

    let filterValue: string;
    filterValue = (value as HTMLInputElement).value;
    console.log(filterValue);
    this.filteredAutores = this.listAutores.filter(autor => autor.nombre.concat(autor.primerApellido, autor.segundoApellido).toLowerCase().includes(filterValue.toLowerCase()));
  } 

  addProduccion() {

    if (this.firstFormGroup.valid && this.secondFormGroup.valid) {
      /* Creamos los objetos que llenamos en el formgroup */
      let desarrollo: Desarrollo;

      
      let rol: RolParticipacion =
      {
        id : this.firstFormGroup.controls['rol_participacion'].value,
        rol: null!
      }
      
      let tipo: TipoDesarrollo=
      {
        id : this.firstFormGroup.controls['tipo_desarrollo'].value,
        tipo: null!
      }
      
      let documento: DocumentoRespaldo= 
      {
        id : this.firstFormGroup.controls['documento_respaldo'].value,
        documento : null!
      }
      
      
       desarrollo= {
        // obtenemos los datos requeridos de la interface articulo desde los formgroups
        // estos datos se obtienen a partir de su formControlName
        nombre: this.firstFormGroup.controls['nombre'].value,
        objetivos: this.firstFormGroup.controls['objetivos'].value,
        resumen: this.firstFormGroup.controls['resumen'].value,
        fecha_de_entrega: this.firstFormGroup.controls['fecha_entrega'].value,
        rolParticipacion: rol,
        tipoDesarrollo: tipo,
        documentoRespaldo: documento
      
      }
      console.log(desarrollo.nombre);
      this.grupo_autores = this.secondFormGroup.controls['autores'].value;



      this.cyadService.postDesarrollo(desarrollo).subscribe({
        next: result => {
          this.buscarDesarrollo(desarrollo);
        },
        error: error => console.log(error)
      });
    }

  }

  buscarDesarrollo(desarrollo: Desarrollo) {
    this.cyadService.findDesarrollo(desarrollo).subscribe({
      next: result2 => {
        console.log("Result was the following " + result2.id);
        
          this.addProducciones(result2.id);
        
      },
      error: error => console.log(error)
    })
  }
  verifyProducciones(DesarrolloId: number) {
    let flag: boolean;
    flag = true;
    if (DesarrolloId == null) {
      console.log("Información nula de la producción académica");
      alert("Información nula de la producción académica");
      flag = false;
    }
    if (this.autores.length > 1) {
      for (let i = 0; i < this.autores.length; i++) {
        const item1 = this.autores.at(i).value;
        const item2 = this.autores.at(i++).value;
        console.log(item1.orden + "hola" + item2.orden);
        if (item1.orden == item2.orden) {
          console.log("The orders are repited, please verify");
          alert("The orders of the authors are repited, please verify");
          flag = false;
        }

      }

      for (let u = 0; u < this.autores.length; u++) {
        const item1 = this.autores.at(u).value;
        const item2 = this.autores.at(u++).value;
        if (item1.autor == item2.autor) {
          console.log("The authors are repited, please verify");
          alert("The authors are repited, please verify");
          flag = false;
        }
      }
    }
    return flag;
  }

  addProducciones(DesarrolloId: number) {
    if (DesarrolloId == null) {
      return;
    }
    for (let i = 0; i < this.autores.length; i++) {
      const item = this.autores.at(i).value;
      let produccion;
      produccion = {
        
        desarrollo: {
          id: DesarrolloId
        },
        autor: {
          id: item.autor
        },
        orden:{
          id: item.orden
        }
        
      }

      this.cyadService.postProduccionDesarrollo(produccion).subscribe({
        next: result => {
          let res:ApiResult;
                res = result; 
                if(res.response == true)
                {
                  alert("EXITO AL REGISTRAR LA PRODUCCIÓN")
                  window.location.reload();
                }
                else
                {
                  alert(res.message);
                }
        },
        error: error => alert('Error al resgistrar desarrollo tecnólogico')
      });
    }
  }

  openDialog(){
    const dialogRef =  this.dialog.open(AutorDetailComponent);
    dialogRef.afterClosed().subscribe(
      val =>{
        if(val === 'save'){
          /**cargando listas */
          this.cyadService.getAutoresEditores().subscribe({
            next:(res)=>{
              this.listAutores = res;
            }

          });
        }
        this.agregarAutor();
      }
    );

  }
}
