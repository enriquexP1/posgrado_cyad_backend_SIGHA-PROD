import { Component, OnInit } from '@angular/core';
import {Chart, registerables} from "chart.js";
import { ProfesorAlumnoPrincipalDatamart } from 'src/app/interfaces/profesor-alumno-principal-datamart';
import { CyadService } from 'src/app/service/cyad.service';

@Component({
  selector: 'app-profesor-alumno-princialp',
  templateUrl: './profesor-alumno-princialp.component.html',
  styleUrls: ['./profesor-alumno-princialp.component.scss']
})
export class ProfesorAlumnoPrincialpComponent implements OnInit {

  public chart?: Chart;
  public lista: ProfesorAlumnoPrincipalDatamart[] = [];
  constructor(private service: CyadService) {
    Chart.register(...registerables);
   }

  ngOnInit(): void {
    this.loadData();
  }

  loadData(){
    this.service.getProfesorAlumnoPrincipal().subscribe({
      next: result => {
        let fixedResult: ProfesorAlumnoPrincipalDatamart[] = result;
        console.log("Llamada a profal" + fixedResult[0].cuenta);
        this.createChart(fixedResult);
      }
    })
  }

  createChart(listaPA: ProfesorAlumnoPrincipalDatamart[]){
    if(this.chart){
      this.chart.destroy();
    }
    console.log("ListaPA[0].cuenta = " + listaPA[0].cuenta);
    this.chart = new Chart("ChartProfesorAlumno", {
      type: 'bar',
      data: {
        labels: ["Profesores y alumnos"],
        datasets: [{
          label: "Profesores",
          data: [listaPA[0].cuenta], //listaPA[1].cuenta],
          backgroundColor: 'rgba(255, 99, 132, 0.2)',
          borderColor: 'rgb(255, 99, 132)',
          borderWidth: 1
        }, {
          label: "Alumnos",
          data: [listaPA[1].cuenta],
          backgroundColor: 'rgba(50, 192, 62, 0.2)',
          borderColor: 'rgb(50, 192, 62)',
          borderWidth: 1
        }],
      },
      options: {
        aspectRatio: 2,
        maintainAspectRatio: true,
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    })
  }
}
