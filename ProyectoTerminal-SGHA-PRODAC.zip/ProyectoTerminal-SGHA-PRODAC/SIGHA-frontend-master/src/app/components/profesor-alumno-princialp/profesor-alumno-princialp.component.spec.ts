import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfesorAlumnoPrincialpComponent } from './profesor-alumno-princialp.component';

describe('ProfesorAlumnoPrincialpComponent', () => {
  let component: ProfesorAlumnoPrincialpComponent;
  let fixture: ComponentFixture<ProfesorAlumnoPrincialpComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProfesorAlumnoPrincialpComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfesorAlumnoPrincialpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
