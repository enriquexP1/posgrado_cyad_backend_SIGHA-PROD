import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TipoDesarrolloDetailComponent } from './tipo-desarrollo-detail.component';

describe('TipoDesarrolloDetailComponent', () => {
  let component: TipoDesarrolloDetailComponent;
  let fixture: ComponentFixture<TipoDesarrolloDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TipoDesarrolloDetailComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TipoDesarrolloDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
