import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TooltipComponent } from '@angular/material/tooltip';
import { Router } from '@angular/router';
import { CyadService } from 'src/app/service/cyad.service';
import { pairs } from 'rxjs';
import { AutorEditor } from 'src/app/interfaces/autor-editor';
import { Orden } from 'src/app/interfaces/orden';
import { OrigenReporte } from 'src/app/interfaces/origen-reporte';
import { InstitucionProduccionAcademica } from 'src/app/interfaces/institucion-produccion-academica';
import { Reporte } from 'src/app/interfaces/reporte';
import { MatDialog } from '@angular/material/dialog';
import { AutorDetailComponent } from '../autor-detail/autor-detail.component';
import { ApiResult } from 'src/app/interfaces/api-result';
@Component({
  selector: 'app-reporte-register',
  templateUrl: './reporte-register.component.html',
  styleUrls: ['./reporte-register.component.scss']
})
export class ReporteRegisterComponent implements OnInit {

  firstFormGroup!: FormGroup;
  secondFormGroup!: FormGroup;
  /**listas */
  listAutores !: AutorEditor[];
  listOrden !: Orden[];
  listInstituciones !: InstitucionProduccionAcademica[];
  listOrigenReporte !: OrigenReporte[];


  public grupo_autores?: any = [];
  autores_select !: any[];
  public filteredAutores?: AutorEditor[];
  constructor(private cyadService: CyadService, private route: Router, private formBuilder: FormBuilder,private dialog: MatDialog) { }

  ngOnInit(): void {
    this.firstFormGroup = this.formBuilder.group({
      titulo: ['', Validators.required],
      fecha_entrega: ['', Validators.required],
      fecha_publicacion: ['', Validators.required],
      numero_paginas: ['', Validators.required],
      descripcion: ['', Validators.required],
      objetivos: ['', Validators.required],
      institucion: ['', Validators.required],
      origen_reporte: ['', Validators.required]

    });
    this.secondFormGroup = this.formBuilder.group({
      autores: this.formBuilder.array([])
    });


    /**cargando listas */
    /*Lista de autores editores */
    this.cyadService.getAutoresEditores().subscribe({
      next: (res) => {
        this.listAutores = res;
        this.filteredAutores = this.listAutores;
      }
    });
    /*Lista de ordenes */
    this.cyadService.getOrdenes().subscribe({
      next: (res) => {
        this.listOrden = res;
      }
    });

    /*Lista de origenes */
    this.cyadService.getOrigenesReporte().subscribe({
      next: (res) => {
        this.listOrigenReporte = res;
      }
    });
    /*Lista de instituciones*/
    this.cyadService.getInstitucionesProduccionAcademica().subscribe(
      {
        next: (res) => {
          this.listInstituciones = res;
        }
      });


  }

  /**agregar campos de forma dinamica */
  get autores() {
    return this.secondFormGroup.get('autores') as FormArray;
  }




  agregarAutor() {
    const autoresFormGroup = this.formBuilder.group({
      autor: ['', Validators.required],
      orden: ['', Validators.required]
    });
    this.autores.push(autoresFormGroup);
  }


  removerAutor(indice: number) {
    this.autores.removeAt(indice);
  }

  refresh() {
    this.autores.controls.splice(0, this.autores.length);
  }

  onKey(value: EventTarget | null){

    let filterValue: string;
    filterValue = (value as HTMLInputElement).value;
    console.log(filterValue);
    this.filteredAutores = this.listAutores.filter(autor => autor.nombre.concat(autor.primerApellido, autor.segundoApellido).toLowerCase().includes(filterValue.toLowerCase()));
  } 

  addProduccion() {

    if (this.firstFormGroup.valid && this.secondFormGroup.valid) {
      /* Creamos los objetos que llenamos en el formgroup */
      let reporte: Reporte;


      let InstitucionProduccionAcademica: InstitucionProduccionAcademica =
      {
        id: this.firstFormGroup.controls['institucion'].value,

      }

      let origen: OrigenReporte =
      {
        id: this.firstFormGroup.controls['origen_reporte'].value,

      }


      reporte = {
        // obtenemos los datos requeridos de la interface articulo desde los formgroups
        // estos datos se obtienen a partir de su formControlName
        titulo: this.firstFormGroup.controls['titulo'].value,
        fecha_entrega: this.firstFormGroup.controls['fecha_entrega'].value,
        fecha_publicacion: this.firstFormGroup.controls['fecha_publicacion'].value,
        numero_paginas: this.firstFormGroup.controls['numero_paginas'].value,
        descripcion: this.firstFormGroup.controls['descripcion'].value,
        objetivos: this.firstFormGroup.controls['objetivos'].value,
        institucion: InstitucionProduccionAcademica,
        origenReporte: origen


      }
      console.log(reporte.descripcion);
      this.grupo_autores = this.secondFormGroup.controls['autores'].value;



      this.cyadService.postReporte(reporte).subscribe({
        next: result => {
          this.buscarReporte(reporte);
        },
        error: error => console.log(error)
      });
    }

  }

  buscarReporte(reporte: Reporte) {
    this.cyadService.findReporte(reporte).subscribe({
      next: result2 => {
        console.log("Result was the following " + result2.id);
       
          this.addProducciones(result2.id);
        
      },
      error: error => console.log(error)
    })
  }
  

  addProducciones(ReporteId: number) {
    if (ReporteId == null) {
      return;
    }
    for (let i = 0; i < this.autores.length; i++) {
      const item = this.autores.at(i).value;
      let produccion;
      produccion = {

        reporte: {
          id: ReporteId
        },
        autorEditor: {
          id: item.autor
        },
        orden: {
          id: item.orden
        }

      }

      this.cyadService.postProduccionReporte(produccion).subscribe({
        next: result => {
          let res:ApiResult;
                res = result; 
                if(res.response == true)
                {
                  alert("EXITO AL REGISTRAR LA PRODUCCIÓN")
                  window.location.reload();
                }
                else
                {
                  alert(res.message);
                }
        },
        error: error => alert('Error al resgistrar Reporte')
      });
    }
  }
  openDialog(){
    const dialogRef =  this.dialog.open(AutorDetailComponent);
    dialogRef.afterClosed().subscribe(
      val =>{
        if(val === 'save'){
          /**cargando listas */
          this.cyadService.getAutoresEditores().subscribe({
            next:(res)=>{
              this.listAutores = res;
            }

          });
        }
        this.agregarAutor();
      }
    );

  }
}
