import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReporteRegisterComponent } from './reporte-register.component';

describe('ReporteRegisterComponent', () => {
  let component: ReporteRegisterComponent;
  let fixture: ComponentFixture<ReporteRegisterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReporteRegisterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReporteRegisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
