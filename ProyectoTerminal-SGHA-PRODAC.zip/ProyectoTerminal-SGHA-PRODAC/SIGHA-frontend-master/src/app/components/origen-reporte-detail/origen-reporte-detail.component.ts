import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { OrigenReporte } from 'src/app/interfaces/origen-reporte';
import { CyadService } from 'src/app/service/cyad.service';

@Component({
  selector: 'app-origen-reporte-detail',
  templateUrl: './origen-reporte-detail.component.html',
  styleUrls: ['./origen-reporte-detail.component.scss']
})
export class OrigenReporteDetailComponent implements OnInit {

  areaForm!: FormGroup;
  title: string = "Nuevo tipo de origen de reporte";
  actionBtn: string = "Guardar";

  

  constructor(
    private cyadService: CyadService,
    private formBuilder: FormBuilder,
    public dialogRef: MatDialogRef<OrigenReporteDetailComponent>,
    @Inject(MAT_DIALOG_DATA) public editData: OrigenReporte,
  ) { }

  ngOnInit(): void {
    /*Agregando validaciones a los input*/
    this.areaForm = this.formBuilder.group({
      origenReporte: ['', Validators.required],
    });

    /*Al iniciar el cuadro de dialogo
    si se tarta de una edición*/
    if (this.editData) {
      this.title = "Actualizar tipo de origen de reporte";
      this.actionBtn = "Actualizar";
      this.areaForm.controls['origenReporte'].setValue(this.editData.origen);
    }

    /*El id es un campo gestionado por el servicio*/
    //this.areaForm.controls['id'].disable();



  }

  submitOrigenReporte() {
    if (this.actionBtn == "Guardar") {
      this.addOrigenReporte();
    } else if (this.actionBtn == "Actualizar") {
      
    }
  }
  onNoClick(): void {
    this.dialogRef.close();
  }

  addOrigenReporte() {
    if (!this.editData) {
      if (this.areaForm.valid) {

        

        /**estructura */
        let origenReporte: OrigenReporte;

        origenReporte = {
          origen: this.areaForm.controls['origenReporte'].value,
        }


        console.log(origenReporte);
        /**llamada al servicio */
        this.cyadService.postOrigenReporte(origenReporte)
          .subscribe({
            next: (res) => {
              console.log(res);
              alert("Tipo de origen de reporte add successfully");
              this.areaForm.reset();
              this.dialogRef.close('save');
            },
            error: (err) => {
              alert("Error while adding the tipo de origen de reporte " + err);
            }
          })
      }
    }
   
  }


}
