import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OrigenReporteDetailComponent } from './origen-reporte-detail.component';

describe('OrigenReporteDetailComponent', () => {
  let component: OrigenReporteDetailComponent;
  let fixture: ComponentFixture<OrigenReporteDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OrigenReporteDetailComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OrigenReporteDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
