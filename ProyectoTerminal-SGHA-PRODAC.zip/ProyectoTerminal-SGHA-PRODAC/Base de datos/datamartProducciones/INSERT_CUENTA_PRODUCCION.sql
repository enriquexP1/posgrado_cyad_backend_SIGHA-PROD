CREATE DEFINER=`root`@`localhost` PROCEDURE `INSERT_CUENTA_PRODUCCION`(
IN in_produccion VARCHAR(255),
IN in_cuenta int(11)
)
BEGIN
INSERT INTO db_cyad_producciones_datamart.CUENTA_PRODUCCION (TIPO_PRODUCCION, CUENTA) VALUES 
(in_produccion , in_cuenta)
ON DUPLICATE KEY UPDATE 
TIPO_PRODUCCION = in_produccion,
CUENTA = in_cuenta;

END