CREATE DEFINER=`root`@`localhost` PROCEDURE `EXTRAER_ALUMNO_PRINCIPAL`()
BEGIN
		-- variables para extracción de información
    -- tabla FRECUENCIA_PRODUCCION_ACADEMICA
    DECLARE var_cuenta INT(11);
    DECLARE var_profesor_alumno BIT(1);
    
	
    
    -- INDICADOR DE FINAL 
    
    DECLARE var_final_profal INTEGER DEFAULT 0;
    
       DECLARE cursor_profesor_alumno CURSOR FOR 
SELECT PROFESOR_ALUMNO, COUNT(NOMBRE)  AS CUENTA_PRODUCCIONES  FROM
db_cyad_producciones_datamart.CAT_AUTOR_EDITOR 
INNER JOIN  db_cyad_producciones_datamart.PRODUCCIONES_GENERALES ON CAT_AUTOR_EDITOR.ID = PRODUCCIONES_GENERALES.ID_AUTOR_EDITOR
WHERE  PRODUCCIONES_GENERALES.ORDEN=1 && CAT_AUTOR_EDITOR.PROFESOR_ALUMNO = 1;

       DECLARE CONTINUE HANDLER FOR NOT FOUND SET var_final_profal  = 1;
    
    OPEN cursor_profesor_alumno;
    bucle_profesor_alumno: LOOP
		FETCH cursor_profesor_alumno INTO var_profesor_alumno  , var_cuenta;
        
         IF var_final_profal  = 1 THEN
			LEAVE bucle_profesor_alumno;
		END IF;
      
        CALL INSERT_PROFESOR_ALUMNO_PRINCIPAL(var_profesor_alumno  , var_cuenta);
    
    END LOOP bucle_profesor_alumno;
    CLOSE cursor_profesor_alumno;
    
    END