CREATE DEFINER=`root`@`localhost` PROCEDURE `EXTRAER_DATA_AUTOR_EDITOR`()
BEGIN
		-- variables para extracción de información
    -- tabla catAutor
    DECLARE var_id BIGINT(20);
    DECLARE var_autor_editor BIT(1);
    DECLARE var_profesor_alumno BIT(1);
    DECLARE var_nombre VARCHAR(255);
	DECLARE var_ap_paterno VARCHAR(255);
	DECLARE var_ap_materno VARCHAR(255);
    DECLARE var_editorial VARCHAR(255);
    
	
    
    -- INDICADOR DE FINAL 
    
    DECLARE var_final_autor_editor INTEGER DEFAULT 0;
    
       DECLARE cursor_autor_editor CURSOR FOR  SELECT ID, AUTOR_EDITOR,  PROFESOR_ALUMNO, NOMBRE , PRIMER_APELLIDO , SEGUNDO_APELLIDO,  EDITORIAL FROM db_cyad_posgrado_producciones.AUTOR_EDITOR;
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET var_final_autor_editor = 1;
    
    OPEN cursor_autor_editor;
    bucle_autores_editores: LOOP
		FETCH cursor_autor_editor INTO var_id, var_autor_editor, var_profesor_alumno , var_nombre , var_ap_paterno, var_ap_materno, var_editorial;
        
         IF var_final_autor_editor = 1 THEN
			LEAVE bucle_autores_editores;
		END IF;
      
        CALL INSERT_AUTOR_EDITOR_DATAMART(var_id,var_autor_editor, var_profesor_alumno , var_nombre , var_ap_paterno, var_ap_materno, var_editorial);
    
    END LOOP bucle_autores_editores;
    CLOSE cursor_autor_editor;
       
END