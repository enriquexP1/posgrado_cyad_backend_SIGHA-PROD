CREATE DEFINER=`root`@`localhost` PROCEDURE `EXTRAER_CUENTA_PRODUCCION`()
BEGIN
		-- variables para extracción de información
    -- tabla FRECUENCIA_PRODUCCION_ACADEMICA
    DECLARE var_cuenta INT(11);
    DECLARE var_tipo_produccion VARCHAR(255);
    
	
    
    -- INDICADOR DE FINAL 
    
    DECLARE var_final_cuenta INTEGER DEFAULT 0;
    
       DECLARE cursor_cuenta CURSOR FOR  SELECT TIPO_PRODUCCION ,COUNT(TIPO_PRODUCCION_ACADEMICA)  FROM db_cyad_producciones_datamart.CAT_PRODUCCION_ACADEMICA INNER JOIN db_cyad_producciones_datamart.PRODUCCIONES_GENERALES ON   CAT_PRODUCCION_ACADEMICA.ID = PRODUCCIONES_GENERALES.TIPO_PRODUCCION_ACADEMICA GROUP BY TIPO_PRODUCCION  ORDER BY TIPO_PRODUCCION ;
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET var_final_cuenta  = 1;
    
    OPEN cursor_cuenta;
    bucle_cuenta: LOOP
		FETCH cursor_cuenta INTO var_tipo_produccion , var_cuenta;
        
         IF var_final_cuenta  = 1 THEN
			LEAVE bucle_cuenta;
		END IF;
      
        CALL INSERT_CUENTA_PRODUCCION(var_tipo_produccion , var_cuenta);
    
    END LOOP bucle_cuenta;
    CLOSE cursor_cuenta;
    
    END