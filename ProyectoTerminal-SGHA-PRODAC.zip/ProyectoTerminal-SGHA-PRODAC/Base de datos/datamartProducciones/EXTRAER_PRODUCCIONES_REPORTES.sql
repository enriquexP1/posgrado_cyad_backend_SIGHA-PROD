CREATE DEFINER=`root`@`localhost` PROCEDURE `EXTRAER_PRODUCCIONES_REPORTES`()
BEGIN
	DECLARE var_fecha_produccion DATETIME(6);
    DECLARE var_id_produccion BIGINT(20);
    DECLARE var_orden INT(11);
    DECLARE var_id_autor_editor BIGINT(20);
    DECLARE var_tipo_produccion BIGINT(20);
   
   -- indicador de final
    DECLARE var_final INTEGER DEFAULT 0;
   
    
   -- CURSORES PARA SELECCION DE DATOS 
   -- Articulos
   DECLARE cursor_reportes CURSOR FOR SELECT REPORTE, AUTOR_EDITOR, ORDEN FROM db_cyad_posgrado_producciones.PRODUCCION_ACADEMICA_REPORTE;
   DECLARE cursor_fecha_reporte CURSOR FOR SELECT FECHA_ENTREGA FROM db_cyad_posgrado_producciones.REPORTE WHERE ID = var_id_produccion; 
   
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET var_final = 1;
    
   SET var_tipo_produccion = 8;
   
   OPEN cursor_reportes;
   bucle_reporte: LOOP
   
	  FETCH cursor_reportes INTO var_id_produccion, var_id_autor_editor, var_orden;
      
    OPEN cursor_fecha_reporte;
			FETCH cursor_fecha_reporte INTO var_fecha_produccion;
	  ClOSE cursor_fecha_reporte;
      
			IF var_final = 1 THEN
			LEAVE bucle_reporte;
			END IF;
            
	-- LAMAMOS A INSERTAR
		 CALL INSERT_PRODUCCION_GENERAL(var_id_produccion, var_fecha_produccion , var_tipo_produccion, var_id_autor_editor, var_orden );
   END LOOP  bucle_reporte;
   CLOSE cursor_reportes;
   
END