CREATE DEFINER=`root`@`localhost` PROCEDURE `EXTRAER_AUTOR_EDITOR_CUENTA_PRODUCCION`()
BEGIN
		-- variables para extracción de información
    -- tabla FRECUENCIA_PRODUCCION_ACADEMICA
DECLARE var_id BIGINT(20);
DECLARE var_nombre VARCHAR(255);
DECLARE var_apellido_paterno VARCHAR(255);
DECLARE var_apellido_materno VARCHAR(255);
DECLARE var_autor_editor BIT(1);
DECLARE var_profesor_alumno BIT(1);
DECLARE var_articulo int(11);
DECLARE var_libro int(11);
DECLARE var_innovacion int(11);
DECLARE var_conferencia int(11);
DECLARE var_presentacion int(11);
DECLARE var_desarrollo int(11);
DECLARE var_memoria int(11);
DECLARE var_reporte int(11);
DECLARE var_documento int(11);
DECLARE var_resena int(11);
    
	
    
    -- INDICADOR DE FINAL 
    
    DECLARE var_final_datos_gen INTEGER DEFAULT 0;
    -- CURSOR DE DATOS GENERALES
       DECLARE cursor_datos_autor_editor CURSOR FOR  SELECT ID, NOMBRE , APELLIDO_PATERNO , APELLIDO_MATERNO , AUTOR_EDITOR , PROFESOR_ALUMNO FROM db_cyad_producciones_datamart.CAT_AUTOR_EDITOR;
	-- CURSORES DE CUENTA DE CADA PRODUCCION ACADEMICA	
       DECLARE cursor_articulo CURSOR FOR SELECT COUNT(ID_AUTOR_EDITOR ) AS CUENTA  FROM db_cyad_producciones_datamart.PRODUCCIONES_GENERALES 
		WHERE PRODUCCIONES_GENERALES.ID_AUTOR_EDITOR = var_id AND PRODUCCIONES_GENERALES.TIPO_PRODUCCION_ACADEMICA = 1;
        
     DECLARE cursor_libro CURSOR FOR SELECT COUNT(ID_AUTOR_EDITOR ) AS CUENTA  FROM db_cyad_producciones_datamart.PRODUCCIONES_GENERALES 
		WHERE PRODUCCIONES_GENERALES.ID_AUTOR_EDITOR = var_id AND PRODUCCIONES_GENERALES.TIPO_PRODUCCION_ACADEMICA = 2;  
        
        DECLARE cursor_innovacion CURSOR FOR SELECT COUNT(ID_AUTOR_EDITOR ) AS CUENTA  FROM db_cyad_producciones_datamart.PRODUCCIONES_GENERALES 
		WHERE PRODUCCIONES_GENERALES.ID_AUTOR_EDITOR = var_id AND PRODUCCIONES_GENERALES.TIPO_PRODUCCION_ACADEMICA = 3;
       
       DECLARE cursor_conferencia CURSOR FOR SELECT COUNT(ID_AUTOR_EDITOR ) AS CUENTA  FROM db_cyad_producciones_datamart.PRODUCCIONES_GENERALES 
		WHERE PRODUCCIONES_GENERALES.ID_AUTOR_EDITOR = var_id AND PRODUCCIONES_GENERALES.TIPO_PRODUCCION_ACADEMICA = 4;
        
        DECLARE cursor_presentacion CURSOR FOR SELECT COUNT(ID_AUTOR_EDITOR ) AS CUENTA  FROM db_cyad_producciones_datamart.PRODUCCIONES_GENERALES 
		WHERE PRODUCCIONES_GENERALES.ID_AUTOR_EDITOR = var_id AND PRODUCCIONES_GENERALES.TIPO_PRODUCCION_ACADEMICA = 5;
        
        DECLARE cursor_desarrollo CURSOR FOR SELECT COUNT(ID_AUTOR_EDITOR ) AS CUENTA  FROM db_cyad_producciones_datamart.PRODUCCIONES_GENERALES 
		WHERE PRODUCCIONES_GENERALES.ID_AUTOR_EDITOR = var_id AND PRODUCCIONES_GENERALES.TIPO_PRODUCCION_ACADEMICA = 6;
        
        DECLARE cursor_memoria CURSOR FOR SELECT COUNT(ID_AUTOR_EDITOR ) AS CUENTA  FROM db_cyad_producciones_datamart.PRODUCCIONES_GENERALES 
		WHERE PRODUCCIONES_GENERALES.ID_AUTOR_EDITOR = var_id AND PRODUCCIONES_GENERALES.TIPO_PRODUCCION_ACADEMICA = 7;
        
        DECLARE cursor_reporte CURSOR FOR SELECT COUNT(ID_AUTOR_EDITOR ) AS CUENTA  FROM db_cyad_producciones_datamart.PRODUCCIONES_GENERALES 
		WHERE PRODUCCIONES_GENERALES.ID_AUTOR_EDITOR = var_id AND PRODUCCIONES_GENERALES.TIPO_PRODUCCION_ACADEMICA = 8;
        
        DECLARE cursor_documento CURSOR FOR SELECT COUNT(ID_AUTOR_EDITOR ) AS CUENTA  FROM db_cyad_producciones_datamart.PRODUCCIONES_GENERALES 
		WHERE PRODUCCIONES_GENERALES.ID_AUTOR_EDITOR = var_id AND PRODUCCIONES_GENERALES.TIPO_PRODUCCION_ACADEMICA = 9;
        
        DECLARE cursor_resena CURSOR FOR SELECT COUNT(ID_AUTOR_EDITOR ) AS CUENTA  FROM db_cyad_producciones_datamart.PRODUCCIONES_GENERALES 
		WHERE PRODUCCIONES_GENERALES.ID_AUTOR_EDITOR = var_id AND PRODUCCIONES_GENERALES.TIPO_PRODUCCION_ACADEMICA = 10;
        
        
       DECLARE CONTINUE HANDLER FOR NOT FOUND SET var_final_datos_gen = 1;
    
    OPEN cursor_datos_autor_editor;
    bucle_datos_autor_editor: LOOP
    
		FETCH cursor_datos_autor_editor INTO var_id , var_nombre , var_apellido_paterno, var_apellido_materno, var_autor_editor, var_profesor_alumno ;
        
        -- TOMAMOS LA CUENTA DE CADA PRODUCCION ACADEMICA
        OPEN cursor_articulo;
        FETCH cursor_articulo INTO var_articulo;
        CLOSE cursor_articulo;
        
        OPEN cursor_libro;
        FETCH cursor_libro INTO var_libro;
        CLOSE cursor_libro;
        
        OPEN cursor_innovacion;
        FETCH cursor_innovacion INTO var_innovacion;
        CLOSE cursor_innovacion;
        
         OPEN cursor_conferencia;
        FETCH cursor_conferencia INTO var_conferencia;
        CLOSE cursor_conferencia;
        
         OPEN cursor_presentacion;
        FETCH cursor_presentacion INTO var_presentacion;
        CLOSE cursor_presentacion;
        
        OPEN cursor_desarrollo;
        FETCH cursor_desarrollo INTO var_desarrollo;
        CLOSE cursor_desarrollo;
        
        OPEN cursor_memoria;
        FETCH cursor_memoria INTO var_memoria;
        CLOSE cursor_memoria;
        
        OPEN cursor_reporte;
        FETCH cursor_reporte INTO var_reporte;
        CLOSE cursor_reporte;
        
        OPEN cursor_documento;
        FETCH cursor_documento INTO var_documento;
        CLOSE cursor_documento;
        
         OPEN cursor_resena;
        FETCH cursor_resena INTO var_resena;
        CLOSE cursor_resena;
        
         IF var_final_datos_gen = 1 THEN
			LEAVE  bucle_datos_autor_editor;
		END IF;
      
       CALL INSERT_AUTOR_EDITOR_CUENTA_PRODUCCION(
var_id,
var_nombre,
 var_apellido_paterno,
var_apellido_materno ,
 var_autor_editor ,
 var_profesor_alumno ,
 var_articulo ,
 var_libro ,
 var_innovacion ,
 var_conferencia ,
 var_presentacion ,
 var_desarrollo,
 var_memoria,
 var_reporte,
 var_documento,
 var_resena 
       );
    
    END LOOP  bucle_datos_autor_editor;
    CLOSE cursor_datos_autor_editor;
    
    END