CREATE DEFINER=`root`@`localhost` PROCEDURE `INSERT_AUTOR_EDITOR_CUENTA_PRODUCCION`(
IN in_id  BIGINT(20),
IN in_nombre VARCHAR(255),
IN in_apellido_paterno VARCHAR(255),
IN in_apellido_materno VARCHAR(255),
IN in_autor_editor BIT(1),
IN in_profesor_alumno BIT(1),
IN in_articulo int(11),
IN in_libro int(11),
IN in_innovacion int(11),
IN in_conferencia int(11),
IN in_presentacion int(11),
IN in_desarrollo int(11),
IN in_memoria int(11),
IN in_reporte int(11),
IN in_documento int(11),
IN in_resena int(11)
)
BEGIN
INSERT INTO db_cyad_producciones_datamart.AUTOR_EDITOR_CUENTA_PRODUCCION
 (ID,NOMBRE, APELLIDO_PATERNO ,APELLIDO_MATERNO,AUTOR_EDITOR, PROFESOR_ALUMNO,
 ARTICULO,
 LIBRO,
 INNOVACION,
 CONFERENCIA,
 PRESENTACION,
 DESARROLLO,
 MEMORIA,
 REPORTE,
 DOCUMENTO,
 RESENA) 
 VALUES 
(in_id,in_nombre,in_apellido_paterno,in_apellido_materno, in_autor_editor,in_profesor_alumno,
in_articulo,
in_libro,
in_innovacion,
in_conferencia, 
in_presentacion ,
in_desarrollo,
in_memoria,
in_reporte ,
in_documento,
in_resena )
ON DUPLICATE KEY UPDATE 
ID = in_id,
NOMBRE = in_nombre,
APELLIDO_PATERNO =in_apellido_paterno,
APELLIDO_MATERNO = in_apellido_materno,
AUTOR_EDITOR = in_autor_editor,
PROFESOR_ALUMNO = in_profesor_alumno,
ARTICULO = in_articulo,
LIBRO = in_libro,
INNOVACION = in_innovacion,
CONFERENCIA = in_conferencia,
PRESENTACION = in_presentacion,
DESARROLLO = in_desarrollo,
MEMORIA = in_memoria,
REPORTE = in_reporte,
DOCUMENTO = in_documento,
RESENA = in_resena ;
 

END