CREATE DEFINER=`root`@`localhost` PROCEDURE `EXTRAER_FRECUENCIA_PRODUCCION`()
BEGIN
		-- variables para extracción de información
    -- tabla FRECUENCIA_PRODUCCION_ACADEMICA
    DECLARE var_cuenta INT(11);
    DECLARE var_fecha DATETIME(6);
    
	
    
    -- INDICADOR DE FINAL 
    
    DECLARE var_final_frecuencia INTEGER DEFAULT 0;
    
       DECLARE cursor_frecuencia CURSOR FOR  SELECT FECHA_PRODUCCION AS Fecha, COUNT(ID ) AS Cuenta FROM db_cyad_producciones_datamart.PRODUCCIONES_GENERALES GROUP BY FECHA_PRODUCCION  ORDER BY FECHA_PRODUCCION; 
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET var_final_frecuencia = 1;
    
    OPEN cursor_frecuencia;
    bucle_frecuencia: LOOP
		FETCH cursor_frecuencia INTO var_fecha , var_cuenta;
        
         IF var_final_frecuencia = 1 THEN
			LEAVE bucle_frecuencia;
		END IF;
      
        CALL INSERT_FRECUENCIA_PRODUCCIONES(var_fecha , var_cuenta);
    
    END LOOP bucle_frecuencia;
    CLOSE cursor_frecuencia;
    
    END