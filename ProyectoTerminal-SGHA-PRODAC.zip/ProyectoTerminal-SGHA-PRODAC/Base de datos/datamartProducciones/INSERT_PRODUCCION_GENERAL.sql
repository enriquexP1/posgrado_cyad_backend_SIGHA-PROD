CREATE DEFINER=`root`@`localhost` PROCEDURE `INSERT_PRODUCCION_GENERAL`(
IN in_id_produccion_academica BIGINT(20),
IN in_fecha_produccion DATETIME(6),
IN in_tipo_produccion BIGINT(20),
IN in_autor_editor BIGINT(20),
IN in_orden int(11)
)
BEGIN
	INSERT INTO db_cyad_producciones_datamart.PRODUCCIONES_GENERALES ( ID_PRODUCCION_ACADEMICA,FECHA_PRODUCCION , TIPO_PRODUCCION_ACADEMICA,ID_AUTOR_EDITOR ,ORDEN )
    VALUES (in_id_produccion_academica , in_fecha_produccion , in_tipo_produccion, in_autor_editor,in_orden )
    ON DUPLICATE KEY UPDATE
    ID =ID,
    ID_PRODUCCION_ACADEMICA =in_id_produccion_academica  
    ,FECHA_PRODUCCION = in_fecha_produccion
    , TIPO_PRODUCCION_ACADEMICA = in_tipo_produccion
    ,ID_AUTOR_EDITOR = in_autor_editor
    ,ORDEN = in_orden
    ;
END