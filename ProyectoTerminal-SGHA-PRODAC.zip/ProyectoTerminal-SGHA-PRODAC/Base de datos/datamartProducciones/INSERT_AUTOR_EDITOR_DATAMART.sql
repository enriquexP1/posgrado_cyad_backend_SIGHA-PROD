CREATE DEFINER=`root`@`localhost` PROCEDURE `INSERT_AUTOR_EDITOR_DATAMART`(
	IN in_id BIGINT(20),
	IN in_autor_editor BIT(1) ,
	IN in_profesor_alumno BIT(1),
    IN in_nombre VARCHAR(255),
	IN in_ap_paterno VARCHAR(255),
	IN in_ap_materno VARCHAR(255),
    IN in_editorial varchar(255)
   
)
BEGIN
		INSERT INTO db_cyad_producciones_datamart.CAT_AUTOR_EDITOR (ID, AUTOR_EDITOR,PROFESOR_ALUMNO, NOMBRE, APELLIDO_PATERNO , APELLIDO_MATERNO, EDITORIAL )
        VALUES ( in_id, in_autor_editor ,in_profesor_alumno, in_nombre, in_ap_paterno , in_ap_materno , in_editorial) ON DUPLICATE KEY UPDATE
        ID = in_id,
        NOMBRE = in_nombre,
	    APELLIDO_PATERNO = in_ap_paterno,
	    APELLIDO_MATERNO = in_ap_materno;
END