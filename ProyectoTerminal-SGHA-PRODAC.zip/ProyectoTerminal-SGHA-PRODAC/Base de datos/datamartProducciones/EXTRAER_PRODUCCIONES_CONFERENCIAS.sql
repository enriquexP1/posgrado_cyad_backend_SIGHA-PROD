CREATE DEFINER=`root`@`localhost` PROCEDURE `EXTRAER_PRODUCCIONES_CONFERENCIAS`()
BEGIN
	DECLARE var_fecha_produccion DATETIME(6);
    DECLARE var_id_produccion BIGINT(20);
    DECLARE var_orden INT(11);
    DECLARE var_id_autor_editor BIGINT(20);
    DECLARE var_tipo_produccion BIGINT(20);
   
   -- indicador de final
    DECLARE var_final INTEGER DEFAULT 0;
   
    
   -- CURSORES PARA SELECCION DE DATOS 
   -- Articulos
   DECLARE cursor_conferencias CURSOR FOR SELECT CONFERENCIA_PRESENTACION.ID , PRODUCCION_ACADEMICA_CONFERENCIA_PRESENTACION.AUTOR  FROM db_cyad_posgrado_producciones.CONFERENCIA_PRESENTACION INNER JOIN db_cyad_posgrado_producciones.PRODUCCION_ACADEMICA_CONFERENCIA_PRESENTACION ON PRODUCCION_ACADEMICA_CONFERENCIA_PRESENTACION.ID = CONFERENCIA_PRESENTACION.ID WHERE CONFERENCIA_PRESENTACION.CONFERENCIA_PRESENTACION = FALSE;
   
   DECLARE cursor_fecha_conferencia CURSOR FOR SELECT FECHA_PRESENTACION FROM db_cyad_posgrado_producciones.CONFERENCIA_PRESENTACION WHERE ID = var_id_produccion; 
   
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET var_final = 1;
    
   SET var_tipo_produccion = 4;
   SET var_orden =1;
   
   OPEN cursor_conferencias;
   bucle_conferencia: LOOP
   
	  FETCH cursor_conferencias INTO var_id_produccion, var_id_autor_editor;
      
    OPEN cursor_fecha_conferencia;
			FETCH cursor_fecha_conferencia INTO var_fecha_produccion;
	  ClOSE cursor_fecha_conferencia;
      
			IF var_final = 1 THEN
			LEAVE bucle_conferencia;
			END IF;
            
	-- LAMAMOS A INSERTAR
		 CALL INSERT_PRODUCCION_GENERAL(var_id_produccion, var_fecha_produccion , var_tipo_produccion, var_id_autor_editor, var_orden );
   END LOOP bucle_conferencia;
   CLOSE cursor_conferencias;
   
END