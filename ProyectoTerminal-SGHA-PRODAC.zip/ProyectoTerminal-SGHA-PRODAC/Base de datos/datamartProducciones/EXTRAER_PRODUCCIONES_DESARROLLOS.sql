CREATE DEFINER=`root`@`localhost` PROCEDURE `EXTRAER_PRODUCCIONES_DESARROLLOS`()
BEGIN
	DECLARE var_fecha_produccion DATETIME(6);
    DECLARE var_id_produccion BIGINT(20);
    DECLARE var_orden INT(11);
    DECLARE var_id_autor_editor BIGINT(20);
    DECLARE var_tipo_produccion BIGINT(20);
   
   -- indicador de final
    DECLARE var_final INTEGER DEFAULT 0;
   
    
   -- CURSORES PARA SELECCION DE DATOS 
   -- Libros
   DECLARE cursor_desarrollos CURSOR FOR SELECT DESARROLLO_TECNOLOGICO, AUTOR, ORDEN FROM db_cyad_posgrado_producciones.PRODUCCION_ACADEMICA_DESARROLLO_TECNOLOGICO;
   DECLARE cursor_fecha_desarrollo CURSOR FOR SELECT FECHA_DE_ENTREGA FROM db_cyad_posgrado_producciones.DESARROLLO_TECNOLÓGICO WHERE ID = var_id_produccion; 
   
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET var_final = 1;
    
   SET var_tipo_produccion = 6;
   
   OPEN cursor_desarrollos;
   bucle_desarrollo: LOOP
   
	  
      
	  FETCH cursor_desarrollos INTO var_id_produccion, var_id_autor_editor, var_orden;
      
    OPEN cursor_fecha_desarrollo;
			FETCH cursor_fecha_desarrollo INTO var_fecha_produccion;
	  ClOSE cursor_fecha_desarrollo;
      
			IF var_final = 1 THEN
			LEAVE bucle_desarrollo;
			END IF;
            
	-- LAMAMOS A INSERTAR
		 CALL INSERT_PRODUCCION_GENERAL(var_id_produccion, var_fecha_produccion , var_tipo_produccion, var_id_autor_editor, var_orden );
   END LOOP bucle_desarrollo;
   CLOSE cursor_desarrollos;
     
END