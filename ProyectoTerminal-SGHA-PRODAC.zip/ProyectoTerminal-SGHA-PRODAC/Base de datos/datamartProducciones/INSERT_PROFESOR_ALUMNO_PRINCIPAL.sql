CREATE DEFINER=`root`@`localhost` PROCEDURE `INSERT_PROFESOR_ALUMNO_PRINCIPAL`(
IN in_profesor_alumno BIT(1),
IN in_cuenta int(11)
)
BEGIN
INSERT INTO db_cyad_producciones_datamart.PROFESOR_ALUMNO_PRINCIPAL (PROFESOR_ALUMNO, CUENTA) VALUES 
(in_profesor_alumno , in_cuenta)
ON DUPLICATE KEY UPDATE 
ID = ID,
PROFESOR_ALUMNO = in_profesor_alumno,
CUENTA = in_cuenta;

END