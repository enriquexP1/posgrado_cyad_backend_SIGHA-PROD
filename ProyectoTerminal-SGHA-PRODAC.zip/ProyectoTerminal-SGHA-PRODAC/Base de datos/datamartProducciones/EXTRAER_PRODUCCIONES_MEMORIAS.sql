CREATE DEFINER=`root`@`localhost` PROCEDURE `EXTRAER_PRODUCCIONES_MEMORIAS`()
BEGIN
	DECLARE var_fecha_produccion DATETIME(6);
    DECLARE var_id_produccion BIGINT(20);
    DECLARE var_orden INT(11);
    DECLARE var_id_autor_editor BIGINT(20);
    DECLARE var_tipo_produccion BIGINT(20);
   
   -- indicador de final
    DECLARE var_final INTEGER DEFAULT 0;
   
    
   -- CURSORES PARA SELECCION DE DATOS 
   -- Memorias
   DECLARE cursor_memorias CURSOR FOR SELECT MEMORIA, AUTOR_EDITOR, ORDEN FROM db_cyad_posgrado_producciones.PRODUCCION_ACADEMICA_MEMORIA;
   DECLARE cursor_fecha_memoria CURSOR FOR SELECT FECHA_PUBLICACION FROM db_cyad_posgrado_producciones.MEMORIA WHERE ID = var_id_produccion; 
   
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET var_final = 1;
    
   SET var_tipo_produccion = 7;
   
   OPEN cursor_memorias;
   bucle_memoria: LOOP
   
	  
      
	  FETCH cursor_memorias INTO var_id_produccion, var_id_autor_editor, var_orden;
      
    OPEN cursor_fecha_memoria;
			FETCH cursor_fecha_memoria INTO var_fecha_produccion;
	  ClOSE cursor_fecha_memoria;
      
			IF var_final = 1 THEN
			LEAVE bucle_memoria;
			END IF;
            
	-- LAMAMOS A INSERTAR
		 CALL INSERT_PRODUCCION_GENERAL(var_id_produccion, var_fecha_produccion , var_tipo_produccion, var_id_autor_editor, var_orden );
   END LOOP bucle_memoria;
   CLOSE cursor_memorias;
     
END