CREATE DEFINER=`root`@`localhost` PROCEDURE `RESET_INDICADORES`()
BEGIN
	DELETE FROM db_cyad_producciones_datamart.AUTOR_EDITOR_CUENTA_PRODUCCION;
    DELETE FROM db_cyad_producciones_datamart.CUENTA_PRODUCCION;
    DELETE FROM db_cyad_producciones_datamart.FRECUENCIA_PRODUCCION_ACADEMICA;
    DELETE FROM db_cyad_producciones_datamart.PROFESOR_ALUMNO_PRINCIPAL;
END