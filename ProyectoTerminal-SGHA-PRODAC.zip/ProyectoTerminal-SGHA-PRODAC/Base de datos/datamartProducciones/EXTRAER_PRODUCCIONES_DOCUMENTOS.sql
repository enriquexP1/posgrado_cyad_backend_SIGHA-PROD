CREATE DEFINER=`root`@`localhost` PROCEDURE `EXTRAER_PRODUCCIONES_DOCUMENTOS`()
BEGIN
	DECLARE var_fecha_produccion DATETIME(6);
    DECLARE var_id_produccion BIGINT(20);
    DECLARE var_orden INT(11);
    DECLARE var_id_autor_editor BIGINT(20);
    DECLARE var_tipo_produccion BIGINT(20);
   
   -- indicador de final
    DECLARE var_final INTEGER DEFAULT 0;
   
    
   -- CURSORES PARA SELECCION DE DATOS 
   -- Articulos
   DECLARE cursor_documentos CURSOR FOR SELECT DOCUMENTO_DE_TRABAJO_RESEÑA.ID, PRODUCCION_ACADEMICA_DOCUMENTO_RESENA.AUTOR_EDITOR , PRODUCCION_ACADEMICA_DOCUMENTO_RESENA.ORDEN FROM db_cyad_posgrado_producciones.DOCUMENTO_DE_TRABAJO_RESEÑA INNER JOIN db_cyad_posgrado_producciones.PRODUCCION_ACADEMICA_DOCUMENTO_RESENA ON PRODUCCION_ACADEMICA_DOCUMENTO_RESENA.ID = DOCUMENTO_DE_TRABAJO_RESEÑA.ID   WHERE DOCUMENTO_DE_TRABAJO_RESEÑA.DOCUMENTO_RESEÑA= false;
   DECLARE cursor_fecha_documento CURSOR FOR SELECT FECHA_DE_ENTREGA FROM db_cyad_posgrado_producciones.DOCUMENTO_DE_TRABAJO_RESEÑA WHERE ID = var_id_produccion; 
   
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET var_final = 1;
    
   SET var_tipo_produccion = 9;
   
   OPEN cursor_documentos;
   bucle_documento: LOOP
   
	  FETCH cursor_documentos INTO var_id_produccion, var_id_autor_editor, var_orden;
      
    OPEN cursor_fecha_documento;
			FETCH cursor_fecha_documento INTO var_fecha_produccion;
	  ClOSE cursor_fecha_documento;
      
			IF var_final = 1 THEN
			LEAVE bucle_documento;
			END IF;
            
	-- LAMAMOS A INSERTAR
		 CALL INSERT_PRODUCCION_GENERAL(var_id_produccion, var_fecha_produccion , var_tipo_produccion, var_id_autor_editor, var_orden );
   END LOOP  bucle_documento;
   CLOSE cursor_documentos;
   
END