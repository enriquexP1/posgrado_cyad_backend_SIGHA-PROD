CREATE DEFINER=`root`@`localhost` PROCEDURE `EXTRAER_PRODUCCIONES_LIBROS`()
BEGIN
	DECLARE var_fecha_produccion DATETIME(6);
    DECLARE var_id_produccion BIGINT(20);
    DECLARE var_orden INT(11);
    DECLARE var_id_autor_editor BIGINT(20);
    DECLARE var_tipo_produccion BIGINT(20);
   
   -- indicador de final
    DECLARE var_final INTEGER DEFAULT 0;
   
    
   -- CURSORES PARA SELECCION DE DATOS 
   -- Libros
   DECLARE cursor_libros CURSOR FOR SELECT LIBRO, AUTOR, ORDEN FROM db_cyad_posgrado_producciones.PRODUCCION_ACADEMICA_LIBRO;
   DECLARE cursor_fecha_libro CURSOR FOR SELECT FECHA_PUBLICACION FROM db_cyad_posgrado_producciones.LIBRO WHERE ID = var_id_produccion; 
   
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET var_final = 1;
    
   SET var_tipo_produccion = 2;
   
   OPEN cursor_libros;
   bucle_libro: LOOP
   
	  
      
	  FETCH cursor_libros INTO var_id_produccion, var_id_autor_editor, var_orden;
      
    OPEN cursor_fecha_libro;
			FETCH cursor_fecha_libro INTO var_fecha_produccion;
	  ClOSE cursor_fecha_libro;
      
			IF var_final = 1 THEN
			LEAVE bucle_libro;
			END IF;
            
	-- LAMAMOS A INSERTAR
		 CALL INSERT_PRODUCCION_GENERAL(var_id_produccion, var_fecha_produccion , var_tipo_produccion, var_id_autor_editor, var_orden );
   END LOOP bucle_libro;
   CLOSE cursor_libros;
     
END