CREATE DEFINER=`root`@`localhost` PROCEDURE `INSERT_TIPOS_PRODUCCIONES`()
BEGIN
INSERT INTO db_cyad_producciones_datamart.CAT_PRODUCCION_ACADEMICA (ID,TIPO_PRODUCCION) VALUES 
(1,'Articulo') , 
(2,'libro' ), 
(3,'innovacion') , 
(4,'Conferencia') , 
(5,'Presentacion') ,
(6,'Desarrollo tecnológico') , 
(7,'Memoria') ,
(8,'Reporte') ,
(9,'Documento de trabajo') ,
(10,'Reseñas')
ON DUPLICATE KEY UPDATE 
ID =ID,
TIPO_PRODUCCION = TIPO_PRODUCCION;
END